<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	if(! function_exists('paginationHTML')) {
		function paginationHTML(){
			$config['full_tag_open'] = '<nav align="center"><ul class="pagination">';
			$config['full_tag_close'] = '</ul></nav>';
			$config['first_link'] = '<i class="fa fa-angle-double-left"></i> First';
			$config['last_link'] = ' Last <i class="fa fa-angle-double-right"></i>';
			$config['first_tag_open'] = '<li>';
			$config['first_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li>';
			$config['last_tag_close'] = '</li>';
			$config['next_tag_open'] = '<li>';
			$config['next_tag_close'] = '</li>';
			$config['prev_tag_open'] = '<li>';
			$config['prev_tag_close'] = '</li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="active"><a>';
			$config['cur_tag_close'] = '</a></li>';
			return $config;
		}
	}
	
	if(! function_exists('getMediaPath')) {
		function getMediaPath($path=NULL){
			$media = "../../media/images/";
			if(!is_null($path)) return $media.$path;
			return $media;
		}
	}
	
	if(! function_exists('getUserStatus')) {
		function getUserStatus($key=NULL){
			$status = array(
				'ban',
				'active'
			);
			if(!is_null($key)) return $status[$key];
			return $status;
		}
	}
	if(! function_exists('getEventStatus')) {
		function getEventStatus($key=NULL){
			$status = array(
				'delete',
				'active',
				'cancel'
			);
			if(!is_null($key)) return $status[$key];
			return $status;
		}
	}
	if(! function_exists('getEgStatus')) {
		function getEgStatus($key=NULL){
			$status = array(
				'delete',
				'active'
			);
			if(!is_null($key)) return $status[$key];
			return $status;
		}
	}
	if(! function_exists('getCategoryStatus')) {
		function getCategoryStatus($key=NULL){
			$status = array(
				'delete',
				'active',
				'disable'
			);
			if(!is_null($key)) return $status[$key];
			return $status;
		}
	}
	
	if(! function_exists('getMediaStatus')) {
		function getMediaStatus($key=NULL){
			$status = array(
				'delete',
				'active',
				'disable'
			);
			if(!is_null($key)) return $status[$key];
			return $status;
		}
	}
	
	if(! function_exists('getPostType')) {
		function getPostType($key=NULL){
			$type = array(
				'post',
				'static'
			);
			if(!is_null($key)) return $type[$key];
			return $type;
		}
	}
	
	if(! function_exists('getPostStatus')) {
		function getPostStatus($key=NULL){
			$type = array(
				'delete',
				'active',
				'suspend'
			);
			if(!is_null($key)) return $type[$key];
			return $type;
		}
	}
	
	if(! function_exists('uploadConfig')) {
		function mediaUploadConfig(){
			$config['upload_path'] = './media/images/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size']	= '5000';
			$config['encrypt_name']	= TRUE;
			return $config;
		}
	}
	
	if(! function_exists('alumniUploadConfig')) {
		function alumniUploadConfig(){
			$config['upload_path'] = './media/alumni/';
			$config['allowed_types'] = '*';
			$config['max_size']	= '10240';
			$config['encrypt_name']	= TRUE;
			return $config;
		}
	}
	
	if(! function_exists('readMorePost')) {
		function readMorePost($text,$link="#"){
			$more = '/**more**/';
			$i = strpos($text,$more);
			if($i !== FALSE) return substr($text,-strlen($text),$i).'<a class="" href='.$link.'>Read more</a>';
			return $text.'<p><a class="" href='.$link.'> Details...</a></p>';
		}
	}
	
	if(! function_exists('removeReadmore')) {
		function removeReadmore($text){
			$more = '/**more**/';
			$emptyp = '<p></p>';
			return str_replace($emptyp,"",str_replace($more,"",$text));
		}
	}
	
	if(! function_exists('cleanString')) {
		function cleanString($text){
			return strip_tags(preg_replace("/<img[^>]+\>/i", "(image) ", $text)); 
		}
	}
	
	if(! function_exists('removeReadmore')) {
		function createRandomKey($amount){
			$keyset  = "abcdefghijklmABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
			$randkey = "";
			for ($i=0; $i<$amount; $i++)
				$randkey .= substr($keyset, rand(0, strlen($keyset)-1), 1);
			return $randkey;	
		}
	}
	if(! function_exists('getMenuUrl')) {
		function getMenuUrl($menu){
			$val = explode('=',$menu->option_value);
			switch($val[0]){
				case "post":$url=base_url('home/staticPage/'.$val[1].'/'.$menu->option_name);break;
				case "url":$url=$val[1];break;
				default:$url="#";
			}
			return $url;	
		}
	}
	