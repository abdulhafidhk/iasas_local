<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('test_method'))
{
    function test_method($var = '')
    {
        return $var;
    }   
}

	if(! function_exists('getCategoryStatus')) 
	public function getCategoryStatus($key=NULL){
		$status = array(
			'delete',
			'active',
			'disable'
		);
		if(!is_null($key)) return $status[$key];
		return $status;
	}
	
	if(! function_exists('getPostType')) 
	public function getPostType($key=NULL){
		$type = array(
			'post',
			'static'
		);
		if(!is_null($key)) return $type[$key];
		return $type;
	}