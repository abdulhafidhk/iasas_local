<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Iaadmin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/iaadmin
	 *	- or -  
	 * 		http://example.com/index.php/iaadmin/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/iaadmin/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		// Your own constructor code
		$session= $this->session->all_userdata();
		if(!isset($session['is_login'])){
			redirect(site_url('ia_login'));
		}
	}
	public function index()
	{
		$this->load->model('m_posts');
		$this->load->model('m_users');
		$this->load->model('m_events');
		$this->load->model('m_media');
		$cdata['posts'] = $this->m_posts->select(array('post_status'=>1))->num_rows();
		$cdata['users'] = $this->m_users->select(array('user_status'=>1))->num_rows();
		$cdata['events'] = $this->m_events->select(array('event_status'=>1))->num_rows();
		$cdata['media'] = $this->m_media->select(array('media_status'=>1))->num_rows();
		
		$data['title'] = 'IA TASS - Dashboard';
		$data['active'] = 'dashboard';
		$data['content'] = $this->load->view('admin/v_dashboard',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	public function post()
	{
		$this->load->model('m_posts');
		$this->load->model('m_category');
		$this->load->model('m_media');
		$this->load->library('pagination');
		$this->load->helper('base_value');
		
		/*---------------------------------------------------------------
		Begin pagination Post
		*/
		$config = paginationHTML();
		$config['base_url'] = site_url('iaadmin/post/');
		$config['total_rows'] = $this->m_posts->select()->num_rows();
		$config['per_page'] = 20;
		$config['uri_segment'] = 3;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$cdata['posts'] = $this->m_posts->getPage($config['per_page'],$page);
		$cdata['post_link'] = $this->pagination->create_links();
		$cdata['post_offset'] = $page;
		$cdata['post_total'] = $config['total_rows'];
		/*---------------------------------------------------------------
		END pagination Post
		*/
		$cdata['category'] = $this->m_category->select();
		$cdata['media'] = $this->m_media->select();
		
		$data['title'] = 'IA TASS - Post';
		$data['active'] = 'post';
		$data['content'] = $this->load->view('admin/v_post',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	public function event()
	{
		$this->load->model('m_events');
		$this->load->model('m_eventgroup');
		$this->load->helper('base_value');
		$this->load->library('pagination');
		/*---------------------------------------------------------------
		Begin pagination Post
		*/
		$config = paginationHTML();
		$config['base_url'] = site_url('iaadmin/event/');
		$config['total_rows'] = $this->m_events->selectJoin()->num_rows();
		$config['per_page'] = 20;
		$config['uri_segment'] = 3;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$cdata['events'] = $this->m_events->getPageJoin($config['per_page'],$page);
		$cdata['event_link'] = $this->pagination->create_links();
		$cdata['event_offset'] = $page;
		$cdata['event_total'] = $config['total_rows'];
		/*---------------------------------------------------------------
		END pagination Post
		*/
		$cdata['eventgroup'] = $this->m_eventgroup->select();
		
		$data['title'] = 'IA TASS - Events';
		$data['active'] = 'event';
		$data['content'] = $this->load->view('admin/v_event',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	public function users()
	{
		$this->load->model('m_users');
		$this->load->model('m_usergroup');
		$this->load->helper('base_value');
		$cdata['admin'] = $this->session->userdata('user');
			$uwhere['user_group <>'] = 4;
		$cdata['users'] = $this->m_users->select($uwhere);
		$cdata['usergroup'] = $this->m_usergroup->select();
		$cdata['group'] = $cdata['usergroup']->result();
		
		$data['title'] = 'IA TASS - Users';
		$data['active'] = 'user';
		$data['content'] = $this->load->view('admin/v_user',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	public function menu()
	{
		$this->load->model('m_posts');
		$this->load->model('m_config');
		$cdata['posts'] = $this->m_posts->select(array('post_type'=>1,'post_status'=>1));
		$cdata['option'] = $this->m_config->select(array('option_id <'=>13))->result();
		
		$cdata['menu'] = $this->m_config->select(array('option_type'=>'menu'))->result();
		$cdata['submenu'] = $this->m_config->select(array('option_type'=>'submenu'))->result();
		
		$data['title'] = 'IA TASS - Menu';
		$data['active'] = 'menu';
		$data['content'] = $this->load->view('admin/v_menu',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	public function slide()
	{
		$data['title'] = 'IA TASS - Slides';
		$data['active'] = 'slide';
		$data['content'] = '#SLIDES';
		$this->load->view('admin/v_body',$data);
	}
	public function newsletter()
	{
		$this->load->model('m_media');
		$this->load->model('m_newsletter');
		$this->load->helper('base_value');
		$cdata['media'] = $this->m_newsletter->select();
		$cdata['media'] = $this->m_media->select(array('media_status'=>1));
		$cdata['admin'] = $this->session->all_userdata();
		
		// echo exec("php /public_html/ok.php'");
		$data['title'] = 'IA TASS - Newsletter';
		$data['active'] = 'newsletter';
		$data['content'] = $this->load->view('admin/v_newsletter',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	public function dbAlumni()
	{
		$this->load->model('m_alumni');
		$this->load->helper('base_value');
		$this->load->library('pagination');
		/*---------------------------------------------------------------
		Begin pagination Post
		*/
		$config = paginationHTML();
		$config['base_url'] = site_url('iaadmin/dbAlumni/');
		$config['total_rows'] = $this->m_alumni->select()->num_rows();
		$config['per_page'] = 20;
		$config['uri_segment'] = 3;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		
		$cdata['alumni'] = $this->m_alumni->getPage($config['per_page'],$page);
		$cdata['page_link'] = $this->pagination->create_links();
		$cdata['page_offset'] = $page;
		$cdata['page_total'] = $config['total_rows'];
		/*---------------------------------------------------------------
		END pagination Post
		*/
		
		$data['title'] = 'IA TASS - Data Alumni';
		$data['active'] = 'dbalumni';
		$data['content'] = $this->load->view('admin/v_dbalumni',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	public function guide()
	{
		$data['title'] = 'IA TASS - Guide';
		$data['active'] = 'guide';
		$data['content'] = $this->load->view('admin/v_guide',NULL,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	/*---------------------------------------------------------------------------------------------------------------------------
	* POST
	*--------------------------------------------------------------------------------------------------------------------------*/
	public function addPost(){
		$this->load->model('m_category');
		$this->load->model('m_media');
		$this->load->helper('base_value');
		$cdata['category'] = $this->m_category->select(array('category_status'=>1));
		$cdata['media'] = $this->m_media->select(array('media_status'=>1));
		$cdata['admin'] = $this->session->all_userdata();
		$cdata['post_type'] = getPostType();
		
		$data['title'] = 'IA TASS - Post';
		$data['active'] = 'post';
		$data['content'] = $this->load->view('admin/v_add_post',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	public function savePost(){
		$this->load->model('m_category');
		$this->load->model('m_posts');
		$admin = $this->session->userdata('user');
		if($_POST){
			$post['post_category_id'] = $this->input->post('postCategory');
			$post['post_title'] = $this->input->post('postTitle');
			$post['post_author'] = $admin->user_id;
			$post['post_date'] = time();
			$post['post_status'] = 1;
			$post['post_view'] = 0;
			$post['post_content'] = $this->input->post('postContent');
			$post['post_type'] = $this->input->post('postType');
			$this->m_posts->add($post);
			$this->session->set_flashdata('notice','Post '.$post['post_title'].' added');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}
		
	}
	public function editPost($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->load->model('m_users');
			$this->load->model('m_media');
			$this->load->model('m_posts');
			$this->load->model('m_category');
			$this->load->helper('base_value');
			
			$admin = $this->session->userdata('user');
			$post = $this->m_posts->get(array('post_id'=>$id));
			$cdata['post'] = $post;
			$cdata['author'] = $this->m_users->get(array('user_id'=>$post->post_author));
			$cdata['category'] = $this->m_category->select(array('category_status'=>1));
			$cdata['media'] = $this->m_media->select(array('media_status'=>1));
			$cdata['post_type'] = getPostType();
			
			$data['title'] = 'IA TASS - Post';
			$data['active'] = 'post';
			$data['content'] = $this->load->view('admin/v_edit_post',$cdata,TRUE);
			$this->load->view('admin/v_body',$data);
		}
	}
	public function updatePost(){
		$this->load->model('m_category');
		$this->load->model('m_posts');
		$admin = $this->session->userdata('user');
		if($_POST){
			$id = $this->input->post('postId');
			$post['post_title'] = $this->input->post('postTitle');
			$post['post_category_id'] = $this->input->post('postCategory');
			$post['post_author'] = $admin->user_id;
			$post['post_date'] = time();
			$post['post_status'] = 1;
			$post['post_content'] = $this->input->post('postContent');
			$post['post_type'] = $this->input->post('postType');
			$this->m_posts->update($post,array('post_id'=>$id));
			$this->session->set_flashdata('notice','Post '.$post['post_title'].' updated');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}
		
	}
	public function deletePost($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->load->model('m_posts');
			$post['post_status'] = 0;
			$this->m_posts->update($post,array('post_id'=>$id));
			$post = $this->m_posts->get(array('post_id'=>$id));
			$this->session->set_flashdata('notice','Post '.$post->post_title.' deleted');
			redirect(site_url('iaadmin/post'),'refresh');
		}
	}
	public function restorePost($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->load->model('m_posts');
			$post['post_status'] = 1;
			$this->m_posts->update($post,array('post_id'=>$id));
			$post = $this->m_posts->get(array('post_id'=>$id));
			$this->session->set_flashdata('notice','Post '.$post->post_title.' restored');
			redirect(site_url('iaadmin/post'),'refresh');
		}
	}
	public function dropPost($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->load->model('m_posts');
			$post = $this->m_posts->get(array('post_id'=>$id));
			if($post->post_status == 0){
				$this->m_posts->delete(array('post_id'=>$id));
				$this->session->set_flashdata('notice','Post '.$post->post_title.' permanently deleted.');
				redirect(site_url('iaadmin/post'),'refresh');
			}else{
				$this->session->set_flashdata('notice',' delete the post first. drop post will permanently delete post.');
				redirect(site_url('iaadmin/post'),'refresh');
			}
		}
	}
	public function saveCategory(){
		$this->load->model('m_category');
		if($_POST){
			$cat['category_name'] = $this->input->post('icategory');
			$cat['category_date'] = time();
			$cat['category_status'] = 1;
			$this->m_category->add($cat);
			$this->session->set_flashdata('notice','Category '.$cat['category_name'].' added');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}
	}
	public function deleteCategory($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->load->model('m_category');
			$cat['category_status'] = 0;
			$this->m_category->update($cat,array('category_id'=>$id));
			$category = $this->m_category->get(array('category_id'=>$id));
			$this->session->set_flashdata('notice','Category '.$category->category_name.' deleted');
			redirect(site_url('iaadmin/post'),'refresh');
		}
	}
	public function restoreCategory($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->load->model('m_category');
			$cat['category_status'] = 1;
			$this->m_category->update($cat,array('category_id'=>$id));
			$category = $this->m_category->get(array('category_id'=>$id));
			$this->session->set_flashdata('notice','Category '.$category->category_name.' restored');
			redirect(site_url('iaadmin/post'),'refresh');
		}
	}
	public function uploadMedia(){
		if(TRUE){
			$this->load->model('m_media');
			$this->load->helper('base_value');
			$this->load->library('upload', mediaUploadConfig());
			if ( ! $this->upload->do_upload('ifile')){
				$this->session->set_flashdata('notice','Error : '.$this->upload->display_errors());
				redirect(site_url('iaadmin/post'),'refresh');
			}else{
				$data = $this->upload->data();
				$media['media_name'] = $data['file_name'];
				$media['media_realname'] = $data['orig_name'];
				$media['media_realpath'] = $data['full_path'];
				$media['media_url'] = 'media/images/'.$data['file_name'];
				$media['media_ext'] = $data['file_ext'];
				$media['media_size'] = $data['file_size'];
				$media['media_status'] = 1;
				$media['media_gallery'] = $this->input->post('igallery');
				$this->m_media->add($media);
				$this->session->set_flashdata('notice','Upload media '.$data['orig_name']);
				redirect(site_url('iaadmin/post'),'refresh');
			}
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}
	}
	public function deleteMedia($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->load->model('m_media');
			$med['media_status'] = 0;
			$this->m_media->update($med,array('media_id'=>$id));
			$media = $this->m_media->get(array('media_id'=>$id));
			$this->session->set_flashdata('notice','Media '.$media->media_realname.' deleted');
			redirect(site_url('iaadmin/post'),'refresh');
		}
	}
	public function restoreMedia($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->load->model('m_media');
			$med['media_status'] = 1;
			$this->m_media->update($med,array('media_id'=>$id));
			$media = $this->m_media->get(array('media_id'=>$id));
			$this->session->set_flashdata('notice','Media '.$media->media_realname.' restored');
			redirect(site_url('iaadmin/post'),'refresh');
		}
	}
	public function dropMedia($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/post'),'refresh');
		}else{
			$this->load->model('m_media');
			$media = $this->m_media->get(array('media_id'=>$id));
			if($media->media_status == 0){
				$this->m_media->delete(array('media_id'=>$id));
				if(file_exists($media->media_realpath)) unlink($media->media_realpath);
				$this->session->set_flashdata('notice','Media '.$media->media_realpath.' permanently deleted');
				redirect(site_url('iaadmin/post'),'refresh');
			}else{
				$this->session->set_flashdata('notice','Cant delete media '.$media->media_realname.'');
				redirect(site_url('iaadmin/post'),'refresh');
			}
		}
	}
	public function searchPost($title=NULL){
		if(is_null($title)){
			$title = $this->input->post('psearch');
		}
		$this->load->model('m_posts');
		$this->load->model('m_category');
		$this->load->model('m_media');
		$this->load->library('pagination');
		$this->load->helper('base_value');
		
		/*---------------------------------------------------------------
		Begin pagination Post
		*/
			$like['post_title'] = $title;
		$config = paginationHTML();
		$config['base_url'] = site_url('iaadmin/searchPost/'.$title.'/');
		$config['total_rows'] = $this->m_posts->selectLike($like)->num_rows();
		$config['per_page'] = 1;
		$config['uri_segment'] = 4;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$cdata['posts'] = $this->m_posts->getPageLike($config['per_page'],$page,$like);
		$cdata['post_link'] = $this->pagination->create_links();
		$cdata['post_offset'] = $page;
		$cdata['post_total'] = $config['total_rows'];
		/*---------------------------------------------------------------
		END pagination Post
		*/
		$cdata['category'] = $this->m_category->select();
		$cdata['media'] = $this->m_media->select();
		
		$data['title'] = 'IA TASS - Post';
		$data['active'] = 'post';
		$data['content'] = $this->load->view('admin/v_post',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	/*---------------------------------------------------------------------------------------------------------------------------
	* Events
	*--------------------------------------------------------------------------------------------------------------------------*/
	public function addEvent(){
		$this->load->model('m_eventgroup');
		$this->load->model('m_media');
		$this->load->helper('base_value');
		$cdata['eventgroup'] = $this->m_eventgroup->select(array('eg_status'=>1));
		$cdata['media'] = $this->m_media->select(array('media_status'=>1));
		
		$data['title'] = 'IA TASS - Event';
		$data['active'] = 'event';
		$data['content'] = $this->load->view('admin/v_add_event',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	public function saveEvent(){
		if($_POST){
			$this->load->model('m_events');
			$admin = $this->session->userdata('user');
			$event['event_group'] = $this->input->post('eventGroup');
			$event['event_author'] = $admin->user_id;
			$event['event_date'] = strtotime($this->input->post('eventDate'));
			$event['event_title'] = $this->input->post('eventTitle');
			$event['event_content'] = $this->input->post('eventContent');
			$event['event_location'] = $this->input->post('eventLocation');
			$event['event_status'] = 1;
			$this->m_events->add($event);
			$this->session->set_flashdata('notice','Event '.$event['event_title'].' added');
			redirect(site_url('iaadmin/event'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/event'),'refresh');
		}
	}
	public function editEvent($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/event'),'refresh');
		}else{
			$this->load->model('m_events');
			$this->load->model('m_eventgroup');
			$this->load->model('m_media');
			$this->load->helper('base_value');
			$cdata['eventgroup'] = $this->m_eventgroup->select(array('eg_status'=>1));
			$cdata['event'] = $this->m_events->get(array('event_id'=>$id));
			$cdata['media'] = $this->m_media->select(array('media_status'=>1));
			
			$data['title'] = 'IA TASS - Event';
			$data['active'] = 'event';
			$data['content'] = $this->load->view('admin/v_edit_event',$cdata,TRUE);
			$this->load->view('admin/v_body',$data);
		}
	}
	public function updateEvent(){
		if($_POST){
			$this->load->model('m_events');
			$this->load->model('m_eventgroup');
			$this->load->helper('base_value');
			
			$id = $this->input->post('eventId');
			$event['event_group'] = $this->input->post('eventGroup');
			$event['event_date'] = strtotime($this->input->post('eventDate'));
			$event['event_title'] = $this->input->post('eventTitle');
			$event['event_content'] = $this->input->post('eventContent');
			$event['event_location'] = $this->input->post('eventLocation');
			$this->m_events->update($event,array('event_id'=>$id));
			$this->session->set_flashdata('notice','Event '.$event['event_title'].' updated');
			redirect(site_url('iaadmin/event'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/event'),'refresh');
		}
	}
	public function eventStatus($id=NULL,$status){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/event'),'refresh');
		}else{
			if($status > 2){
				$status = 1;
			}
			$this->load->model('m_events');
			$event['event_status'] = $status;
			$this->m_events->update($event,array('event_id'=>$id));
			$ev = $this->m_events->get(array('event_id'=>$id));
			$this->session->set_flashdata('notice','Event '.$ev->event_title.' changed');
			redirect(site_url('iaadmin/event'),'refresh');
		}
	}
	public function dropEvent($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/event'),'refresh');
		}else{
			$this->load->model('m_events');
			$ev = $this->m_events->get(array('event_id'=>$id));
			if($ev->event_status==0){
				$this->m_events->delete(array('event_id'=>$id));
				$this->session->set_flashdata('notice','Event '.$ev->event_title.' permanently deleted');
			}else{
				$this->session->set_flashdata('notice','Cant delete event '.$ev->event_title.'');
			}
			redirect(site_url('iaadmin/event'),'refresh');
		}
	}
	public function saveEventgroup(){
		if($_POST){
			$this->load->model('m_eventgroup');
			$eg['eg_name'] = $this->input->post('egName');
			$eg['eg_desc'] = $this->input->post('egDesc');
			$eg['eg_status'] = 1;
			$this->m_eventgroup->add($eg);
			$this->session->set_flashdata('notice','Eventgroup '.$eg['eg_name'].' added');
			redirect(site_url('iaadmin/event'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/event'),'refresh');
		}
	}
	public function editEventgroup($id=NULL){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/event'),'refresh');
		}else{
			$this->load->model('m_eventgroup');
			$cdata['eventgroup'] = $this->m_eventgroup->get(array('eg_id'=>$id));
			
			$data['title'] = 'IA TASS - Event';
			$data['active'] = 'event';
			$data['content'] = $this->load->view('admin/v_edit_eventgroup',$cdata,TRUE);
			$this->load->view('admin/v_body',$data);
		}
	
	}
	public function updateEventgroup(){
		if($_POST){
			$this->load->model('m_eventgroup');
			$id= $this->input->post('egId');
			$eg['eg_name'] = $this->input->post('egName');
			$eg['eg_desc'] = $this->input->post('egDesc');
			$this->m_eventgroup->update($eg,array('eg_id'=>$id));
			$this->session->set_flashdata('notice','Eventgroup '.$eg['eg_name'].' updated');
			redirect(site_url('iaadmin/event'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/event'),'refresh');
		}
	}
	public function eventgroupStatus($id=NULL,$status=1){
		if(is_null($id)){
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/event'),'refresh');
		}else{
			if($status > 2){
				$status = 1;
			}
			$this->load->model('m_eventgroup');
			$eg['eg_status'] = $status;
			$this->m_eventgroup->update($eg,array('eg_id'=>$id));
			$eventg = $this->m_eventgroup->get(array('eg_id'=>$id));
			$this->session->set_flashdata('notice','Eventgroup '.$eventg->eg_name.' status changed');
			redirect(site_url('iaadmin/event'),'refresh');
		}
	}
	public function searchEvent($title=NULL){
		if(is_null($title)){
			$title = $this->input->post('esearch');
		}
		$this->load->model('m_events');
		$this->load->model('m_eventgroup');
		$this->load->helper('base_value');
		$this->load->library('pagination');
		/*---------------------------------------------------------------
		Begin pagination event
		*/
			$like['event_title'] = $title;
		$config = paginationHTML();
		$config['base_url'] = site_url('iaadmin/searchEvent/'.$title.'/');
		$config['total_rows'] = $this->m_events->selectJoinLike($like)->num_rows();
		$config['per_page'] = 20;
		$config['uri_segment'] = 4;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$cdata['events'] = $this->m_events->getPageJoinLike($config['per_page'],$page,$like);
		$cdata['event_link'] = $this->pagination->create_links();
		$cdata['event_offset'] = $page;
		$cdata['event_total'] = $config['total_rows'];
		/*---------------------------------------------------------------
		END pagination event
		*/
		$cdata['eventgroup'] = $this->m_eventgroup->select();
		
		$data['title'] = 'IA TASS - Events';
		$data['active'] = 'event';
		$data['content'] = $this->load->view('admin/v_event',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	/*---------------------------------------------------------------------------------------------------------------------------
	* Users
	*--------------------------------------------------------------------------------------------------------------------------*/
	public function saveUser(){
		if($_POST){
			$pass = $this->input->post('ipassword');
			$cpass = $this->input->post('icpassword');
			if($pass === $cpass){
				$this->load->model('m_users');
				$user['user_username'] = $this->input->post('iusername');
				$user['user_name'] = $this->input->post('iname');
				$user['user_email'] = $this->input->post('iemail');
				$user['user_group'] = $this->input->post('iuserGroup');
				$user['user_password'] = md5($cpass);
				$user['user_status'] = 1;
				$user['user_lastlogin'] = 0;
				$this->m_users->add($user);
				$this->session->set_flashdata('notice','User '.$user['user_username'].' added');
				redirect(site_url('iaadmin/users'),'refresh');
			}else{
				$this->session->set_flashdata('notice','Gagal menambah user, password tidak sama');
				redirect(site_url('iaadmin/users'),'refresh');
			}
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/users'),'refresh');
		}
	}
	public function updateUser(){
		if($_POST){
			$admin = $this->session->userdata('user');
			$oldpass = $this->input->post('oldpassword');
			$pass = $this->input->post('ipassword');
			$cpass = $this->input->post('icpassword');
			
			if($admin->user_password == md5($oldpass) && $pass == $cpass){
				$this->load->model('m_users');
				$user['user_password'] = md5($cpass);
				$this->m_users->update($user,array('user_id'=>$admin->user_id));
				$userupdate = $this->m_users->get(array('user_id'=>$admin->user_id));
				$this->session->set_userdata('user',$userupdate);
				$this->session->set_flashdata('notice','Password '.$userupdate->user_username.' updated');
				redirect(site_url('iaadmin/users'),'refresh');
			}else{
				$this->session->set_flashdata('notice','Periksa lagi password anda');
				redirect(site_url('iaadmin/users'),'refresh');
			}
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/users'),'refresh');
		}
	}
	/*---------------------------------------------------------------------------------------------------------------------------
	* Database Alumni
	*--------------------------------------------------------------------------------------------------------------------------*/
	function addAlumni(){
		if($_POST){
			$this->load->model('m_alumni');
			$this->load->helper('base_value');
			$dba['dba_nim'] = $this->input->post('dba_nim');
			$dba['dba_name'] = $this->input->post('dba_name');
			$dba['dba_program'] = $this->input->post('dba_program');
			$dba['dba_yudisium'] = $this->input->post('dba_yudisium');
			$dba['dba_phone'] = $this->input->post('dba_phone');
			$dba['dba_email'] = $this->input->post('dba_email');
			$dba['dba_address'] = $this->input->post('dba_address');
			$dba['dba_extra'] = $this->input->post('dba_extra');
			// exit('<pre>'.var_dump($dba).'</pre>');
			$this->m_alumni->add($dba);
			// $this->session->set_flashdata('notice','Alumni '.$dba['dba_nim'].' - '.$dba['dba_name'].' sudah ditambahkan ke dalam database');
			// redirect(site_url('iaadmin/dbAlumni'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/dbAlumni'),'refresh');
		}
	}
	function deleteAlumni($id=NULL){
		if(!is_null($id)){
			$this->load->model('m_alumni');
			$oldnim = $this->m_alumni->get(array('dba_id'=>$id));
			// $this->m_alumni->delete(array('dba_id'=>$id));
			$this->session->set_flashdata('notice','NIM '.$oldnim->dba_nim.' dengan nama '.$oldnim->dba_name.' sudah terhapus.');
			redirect(site_url('iaadmin/dbAlumni'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/dbAlumni'),'refresh');
		}
	}
	function uploadDataAlumni(){
		$this->load->model('m_media');
		$this->load->model('m_alumni');
		$this->load->helper('base_value');
		$this->load->library('upload', alumniUploadConfig());
		if ( ! $this->upload->do_upload('ifile')){
			$this->session->set_flashdata('notice','Error : '.$this->upload->display_errors());
			redirect(site_url('iaadmin/dbAlumni'),'refresh');
		}else{
			$data = $this->upload->data();
			// $media['media_name'] = $data['file_name'];
			// $media['media_realname'] = $data['orig_name'];
			// $media['media_realpath'] = $data['full_path'];
			// $media['media_url'] = 'media/images/'.$data['file_name'];
			// $media['media_ext'] = $data['file_ext'];
			// $media['media_size'] = $data['file_size'];
			// $media['media_status'] = 1;
			// $media['media_gallery'] = $this->input->post('igallery');
			$delimiter = $this->input->post('delimiter');
			$file = fopen($data['full_path'],"r");
			while(! feof($file)){
				$dtalumni = fgetcsv($file,0,$delimiter);
				if($dtalumni[0]=='NO' || $dtalumni[0]== '' || $dtalumni[0]== 'NIM' || $dtalumni[0]== 'nim') continue;
				$dbalumni['dba_nim'] = (isset($dtalumni[0]))?$dtalumni[0]:'';
				$dbalumni['dba_program'] = (isset($dtalumni[1]))?$dtalumni[1]:'';
				$dbalumni['dba_name'] = (isset($dtalumni[2]))?$dtalumni[2]:'';
				$dbalumni['dba_yudisium'] = (isset($dtalumni[3]))?$dtalumni[3]:'';
				$dbalumni['dba_phone'] = (isset($dtalumni[4]))?$dtalumni[4]:'';
				$dbalumni['dba_email'] = (isset($dtalumni[5]))?$dtalumni[5]:'';
				$dbalumni['dba_address'] = (isset($dtalumni[6]))?$dtalumni[6]:'';
				$dbalumni['dba_extra'] = (isset($dtalumni[7]))?$dtalumni[7]:'';
				// echo '<pre>'.print_r($dbalumni,1).'</pre>';
				$this->m_alumni->add($dbalumni);
			}
			fclose($file);
			unlink($data['full_path']);
			$this->session->set_flashdata('notice','Upload data alumni dari '.$data['orig_name']);
			redirect(site_url('iaadmin/dbAlumni'),'refresh');
		}
	}
	function searchAlumni($q=NULL){
		$this->load->model('m_alumni');
		$this->load->helper('base_value');
		$this->load->library('pagination');
		
		if(is_null($q)){
			$q = $this->input->get('q');
		}
		/*---------------------------------------------------------------
		Begin pagination Post
		*/
		$like['dba_nama'] = $q;
		$config = paginationHTML();
		$config['base_url'] = site_url('iaadmin/searchAlumni/'.$q.'/');
		$config['total_rows'] = $this->m_alumni->selectLike($like)->num_rows();
		$config['per_page'] = 20;
		$config['uri_segment'] = 4;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		
		$cdata['alumni'] = $this->m_alumni->getPageLike($config['per_page'],$page,$like);
		$cdata['page_link'] = $this->pagination->create_links();
		$cdata['page_offset'] = $page;
		$cdata['page_total'] = $config['total_rows'];
		$cdata['searchq'] = $q;
		/*---------------------------------------------------------------
		END pagination Post
		*/
		
		$data['title'] = 'IA TASS - Data Alumni';
		$data['active'] = 'dbalumni';
		$data['content'] = $this->load->view('admin/v_dbalumni',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
}

/* End of file iaadmin.php */
/* Location: ./application/controllers/iaadmin.php */