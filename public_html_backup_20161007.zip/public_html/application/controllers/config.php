<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Config extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/config
	 *	- or -  
	 * 		http://example.com/index.php/config/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/config/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		// Your own constructor code
		$session= $this->session->all_userdata();
		if(!isset($session['is_login'])){
			redirect(site_url('login'));
		}
		$this->load->model('m_config');
	}
	
	public function index()
	{
		$cdata['config'] = $this->m_config->select(array('option_id <'=>10))->result();
		$data['title'] = 'IA TASS - Config';
		$data['active'] = 'config';
		$data['content'] = $this->load->view('admin/v_config',$cdata,TRUE);
		$this->load->view('admin/v_body',$data);
	}
	
	public function save(){
		if($_POST){
			$this->load->library('form_validation');
			foreach($_POST as $key=>$val){
				$this->form_validation->set_rules($key, $key, 'required');
			}
			if($this->form_validation->run()){
				$i=1;
				foreach($_POST as $key=>$val){
					$w['option_id'] = $i++;
					$d['option_value'] = $val;
					$this->m_config->update($d,$w);
				}
				$this->session->set_flashdata('notice','Config Saved!');
				redirect(site_url('config'),'refresh');
			}else{
				$this->session->set_flashdata('notice','All field is required:<br/>');
				redirect(site_url('config'),'refresh');
			}
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('config'),'refresh');
		}
	}
	/*---------------------------------------------------------------------------------------------------------------------------
	* Menu
	*--------------------------------------------------------------------------------------------------------------------------*/
	public function saveMenu(){
		if($_POST){
			$i=10;
			foreach($_POST as $key=>$val){
				$w['option_id'] = $i++;
				$d['option_value'] = $val;
				$this->m_config->update($d,$w);
			}
			$this->session->set_flashdata('notice','Config Saved!');
			redirect(site_url('iaadmin/menu'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/menu'),'refresh');
		}
	}
	
	public function saveAddmenu(){
		if($_POST){
			$cek = $this->input->post('check');
			$menu_name = $this->input->post('iMenu');
			switch($cek){
				case "post": $menu_value = 'post='.$this->input->post('urlMenu');break;
				case "url": $menu_value = 'url='.$this->input->post('urlLink');break;
				default :$menu_value = 'url=#';break;
			}
			$this->m_config->addMenu($menu_name,$menu_value);
			$this->session->set_flashdata('notice','menu '.$menu_name.' added. link to '.$menu_value);
			redirect(site_url('iaadmin/menu'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/menu'),'refresh');
		}
	}
	
	public function saveSubmenu(){
		if($_POST){
			$cek = $this->input->post('check');
			$menu_name = $this->input->post('iMenu');
			$menu_parent = $this->input->post('iParent');
			switch($cek){
				case "post": $menu_value = 'post='.$this->input->post('urlMenu');break;
				case "url": $menu_value = 'url='.$this->input->post('urlLink');break;
				default :$menu_value = 'url=#';break;
			}
			$this->m_config->addSubMenu($menu_name,$menu_value,$menu_parent);
			$this->session->set_flashdata('notice','submenu '.$menu_name.' added. link to '.$menu_value);
			redirect(site_url('iaadmin/menu'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/menu'),'refresh');
		}
	}
	
	public function updateMenu(){
		if($_POST){
			$whr['option_id'] = $this->input->post('option_id');
			$opt['option_name'] = $this->input->post('option_name');
			$opt['option_desc'] = $this->input->post('option_desc');
			$cek = $this->input->post('check');
			switch($cek){
				case "post": $opt['option_value'] = 'post='.$this->input->post('urlMenu');break;
				case "url": $opt['option_value'] = 'url='.$this->input->post('option_value');break;
				default :$opt['option_value'] = 'url=#';break;
			}
			if($opt['option_desc']=='parent'){
				$opt['option_type'] = 'menu';
			}
			$this->m_config->update($opt,$whr);
			$this->session->set_flashdata('notice','berhasil update '.$opt['option_name']);
			redirect(site_url('iaadmin/menu'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/menu'),'refresh');
		}
	}
	
	public function deleteMenus($id=NULL){
		if(!is_null($id)){
			$opt['option_id'] = $id;
			$this->m_config->delete($opt);
			$this->session->set_flashdata('notice','Berhasil delete');
			redirect(site_url('iaadmin/menu'),'refresh');
		}else{
			$this->session->set_flashdata('notice','are you lost ?');
			redirect(site_url('iaadmin/menu'),'refresh');
		}
	}
}