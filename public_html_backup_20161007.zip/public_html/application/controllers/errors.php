<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Errors extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/errors
	 *	- or -  
	 * 		http://example.com/index.php/errors/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * errors/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/errors/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		// Your own constructor code
	}
	function _header($cdata=NULL){
		$data['config'] = $this->m_config->select(array('option_id <'=>13))->result();
		$data['menu'] = $this->m_config->select(array('option_type'=>'menu'));
		$data['cm_home'] = $this->m_config->select(array('option_desc'=>'m:home'))->num_rows();
		$data['cm_org'] = $this->m_config->select(array('option_desc'=>'m:organisasi'))->num_rows();
		$data['cm_news'] = $this->m_config->select(array('option_desc'=>'m:news'))->num_rows();
		$data['cm_events'] = $this->m_config->select(array('option_desc'=>'m:events'))->num_rows();
		$data['cm_gallery'] = $this->m_config->select(array('option_desc'=>'m:gallery'))->num_rows();
		$data['submenu'] = $this->m_config->select(array('option_type'=>'submenu'));
		$data['title'] = 'IA TASS';
		return $data;
	}
	function e404(){
		$this->load->model('m_config');
		$this->output->set_status_header('404');
		$data = $this->_header();
		$data['content'] = $this->load->view('default/v_404',NULL,TRUE);
		$this->load->view('default/v_body.php',$data);
	}
}