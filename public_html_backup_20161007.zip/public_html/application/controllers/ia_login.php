<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ia_login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/login
	 *	- or -  
	 * 		http://example.com/index.php/login/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/login/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		// Your own constructor code
	}
	public function index()
	{
		$session= $this->session->all_userdata();
		if(isset($session['is_login'])){
			redirect(site_url('iaadmin'),'refresh');
		}
		$data['notice'] = $this->session->flashdata('notice');
		$this->load->view('login/v_login.php',$data);
	}
	public function auth(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('iusername', 'Username', 'required');
		$this->form_validation->set_rules('ipassword', 'Password', 'required');
		if($this->form_validation->run() == FALSE){
			$this->session->set_flashdata('notice',validation_errors());
			$this->index();
		}else{
			$this->load->model('m_users');
			$username = $this->input->post('iusername');
			$password = $this->input->post('ipassword');
			$user = $this->m_users->authLogin($username,$password);
			if($user){
				$userdata['user'] = $user;
				$userdata['is_login'] = TRUE;
				$userdata['user_group'] = $user->user_group;
				$this->session->set_userdata($userdata);
				$this->session->set_flashdata('notice','Selamat datang '.$user->user_name);
				redirect(base_url('iaadmin','refresh'));
			}else{
				$this->session->set_flashdata('notice','Username atau password salah.');
				redirect(base_url('ia_login','refresh'));
			}
		}
		
	}
	public function logout(){
		$this->session->sess_destroy();
		redirect(base_url('home','refresh'));
	}
}

/* End of file ia_login.php */
/* Location: ./application/controllers/ia_login.php */