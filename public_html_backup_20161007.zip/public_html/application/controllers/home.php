<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/home
	 *	- or -  
	 * 		http://example.com/index.php/home/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/home/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		// Your own constructor code
		$this->load->model('m_config');
	}
	function _header($cdata=NULL){
		$data['config'] = $this->m_config->select(array('option_id <'=>13))->result();
		$data['menu'] = $this->m_config->select(array('option_type'=>'menu'));
		$data['cm_home'] = $this->m_config->select(array('option_desc'=>'m:home'))->num_rows();
		$data['cm_org'] = $this->m_config->select(array('option_desc'=>'m:organisasi'))->num_rows();
		$data['cm_news'] = $this->m_config->select(array('option_desc'=>'m:news'))->num_rows();
		$data['cm_events'] = $this->m_config->select(array('option_desc'=>'m:events'))->num_rows();
		$data['cm_gallery'] = $this->m_config->select(array('option_desc'=>'m:gallery'))->num_rows();
		$data['submenu'] = $this->m_config->select(array('option_type'=>'submenu'));
		$data['title'] = 'IA TASS';
		return $data;
	}
	public function index()
	{
		$this->load->model('m_posts');
		$this->load->model('m_events');
		$this->load->helper('base_value');
		$cdata['posts'] = $this->m_posts->getPageJoin(4,0,array('post_status'=>1,'post_type'=>0));
		$cdata['events'] = $this->m_events->getPageJoin(4,0,array('event_status'=>1));
		$cdata['profile'] = $this->m_config->get(array('option_id '=>9));
		
		$data = $this->_header($cdata);
		$data['content'] = $this->load->view('default/v_frontpage',$cdata,TRUE);
		$this->load->view('default/v_body.php',$data);
	}
	/*--------------------------------------------------------------------------
	* NEWS/POST
	--------------------------------------------------------------------------*/
	public function news(){
		$this->load->model('m_posts');
		$this->load->library('pagination');
		$this->load->helper('base_value');
		/*---------------------------------------------------------------
		Begin pagination Post
		*/
		$pwhere['post_status'] = 1;$pwhere['post_type'] = 0;$pwhere['post_type'] = 0;
		$config = paginationHTML();
		$config['base_url'] = site_url('home/news');
		$config['total_rows'] = $this->m_posts->selectJoin($pwhere)->num_rows();
		$config['per_page'] = 10;
		$config['display_pages'] = true;
		$config['uri_segment'] = 3;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$cdata['posts'] = $this->m_posts->getPageJoin($config['per_page'],$page,$pwhere);
		$cdata['post_link'] = $this->pagination->create_links();
		$cdata['post_offset'] = $page;
		/*---------------------------------------------------------------
		END pagination Post
		*/
		$data = $this->_header($cdata);
		$data['content'] = $this->load->view('default/v_page',$cdata,TRUE);
		$this->load->view('default/v_body.php',$data);
	}
	
	public function post($id=NULL){
		if(is_null($id)){
			redirect(site_url('home/'),'refresh');
		}else{
			$this->load->model('m_posts');
			$this->load->helper('base_value');
			$pwhere['post_status'] = 1;
			$pwhere['post_id'] = $id;
			$cdata['post'] = $this->m_posts->getJoin($pwhere);
			if(!$cdata['post']){
				redirect(site_url('errors/e404'),'refresh');
			}
				$rwhere['post_status'] = 1;
				$rwhere['post_category_id'] = $cdata['post']->post_category_id;
				$rwhere['post_id <'] = $cdata['post']->post_id;
			$cdata['related'] = $this->m_posts->getPage(10,0,$rwhere);
			$cdata['fb_share'] = $cdata['post']->post_content;
			
			// die($cdata['post']);
			$data = $this->_header($cdata);
			$data['title'] = 'IA TASS - '.$cdata['post']->post_title;
			$data['content'] = $this->load->view('default/v_single',$cdata,TRUE);
			$this->load->view('default/v_body.php',$data);
		}
	}
	/*--------------------------------------------------------------------------
	* EVENT
	--------------------------------------------------------------------------*/
	public function events($cat=NULL){
		$this->load->model('m_events');
		$this->load->library('pagination');
		$this->load->helper('base_value');
		/*---------------------------------------------------------------
		Begin pagination event
		*/
		$pwhere['event_status'] = 1;
		if(!is_null($cat)){
			$pwhere['event_group'] = $cat;
		}
		$config = paginationHTML();
		if(!is_null($cat)){
			$config['base_url'] = site_url('home/events/'.$cat);
		}else{
			$config['base_url'] = site_url('home/events');
		}
		$config['total_rows'] = $this->m_events->selectJoin($pwhere)->num_rows();
		$config['per_page'] = 10;
		$config['display_pages'] = true;
		if(!is_null($cat)){
			$config['uri_segment'] = 4;
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}else{
			$config['uri_segment'] = 3;
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		}
		$this->pagination->initialize($config); 
		$cdata['events'] = $this->m_events->getPageJoin($config['per_page'],$page,$pwhere);
		$cdata['event_link'] = $this->pagination->create_links();
		$cdata['event_offset'] = $page;
		/*---------------------------------------------------------------
		END pagination event
		*/
		$data = $this->_header($cdata);
		$data['content'] = $this->load->view('default/v_page_event',$cdata,TRUE);
		$this->load->view('default/v_body.php',$data);
	}
	public function event($id=NULL){
		if(is_null($id)){
			redirect(site_url('home/events'),'refresh');
		}else{
			$this->load->model('m_events');
			$this->load->helper('base_value');
			$ewhere['event_status'] = 1;
			$ewhere['event_id'] = $id;
			$cdata['event'] = $this->m_events->getJoin($ewhere);
			if(!$cdata['event']){
				redirect(site_url('errors/e404'),'refresh');
			}
			$cdata['fb_share'] = $cdata['event']->event_content;
			$data = $this->_header($cdata);
			$data['title'] = 'IA TASS - '.$cdata['event']->event_title;
			$data['content'] = $this->load->view('default/v_single_event',$cdata,TRUE);
			$this->load->view('default/v_body.php',$data);			
		}
	}
	public function search($title=NULL){
		if(is_null($title)){
			$title = $this->input->post('search');
		}
		$cdata['search'] = $title;
		$this->load->model('m_posts');
		$this->load->model('m_events');
		$this->load->library('pagination');
		$this->load->helper('base_value');
		/*---------------------------------------------------------------
		Begin pagination Post
		*/
			$pwhere['post_status'] = 1;$pwhere['post_type'] = 0;
			$pwhere['post_title'] = $title;
		$config = paginationHTML();
		$config['base_url'] = site_url('home/search'.$title);
		$config['total_rows'] = $this->m_posts->selectJoinLike($pwhere)->num_rows();
		$config['per_page'] = 10;
		$config['display_pages'] = true;
		$config['uri_segment'] = 4;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$cdata['posts'] = $this->m_posts->getPageJoinLike($config['per_page'],$page,$pwhere);
		$cdata['post_link'] = $this->pagination->create_links();
		$cdata['post_offset'] = $page;
		/*---------------------------------------------------------------
		END pagination Post
		*/
		/*---------------------------------------------------------------
		Begin pagination event
		*/
			$ewhere['event_status'] = 1;
			$ewhere['event_title'] = $title;
		$config = paginationHTML();
		$config['base_url'] = site_url('home/search/'.$title);
		$config['total_rows'] = $this->m_events->selectJoinLike($ewhere)->num_rows();
		$config['per_page'] = 10;
		$config['display_pages'] = true;
		$config['uri_segment'] = 4;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$cdata['events'] = $this->m_events->getPageJoinLike($config['per_page'],$page,$ewhere);
		$cdata['event_link'] = $this->pagination->create_links();
		$cdata['event_offset'] = $page;
		/*---------------------------------------------------------------
		END pagination event
		*/
		$data = $this->_header($cdata);
		$data['content'] = $this->load->view('default/v_search',$cdata,TRUE);
		$this->load->view('default/v_body.php',$data);
	}
	public function visi_misi(){
		$this->load->model('m_config');
		$org = $this->m_config->get(array('option_id'=>10));
		if($org->option_value == '#'){
			$this->index();
		}else{
			$this->staticPage($org->option_value);
		}
	}
	public function program(){
		$this->load->model('m_config');
		$org = $this->m_config->get(array('option_id'=>11));
		if($org->option_value == '#'){
			$this->index();
		}else{
			$this->staticPage($org->option_value);
		}
	}
	public function struktur(){
		$this->load->model('m_config');
		$org = $this->m_config->get(array('option_id'=>12));
		if($org->option_value == '#'){
			$this->index();
		}else{
			$this->staticPage($org->option_value);
		}
	}
	
	public function staticPage($id=NULL,$name=NULL){
		if(is_null($id)){
			redirect(site_url('home/'),'refresh');
		}else{
			$this->load->model('m_posts');
			$this->load->helper('base_value');
			$pwhere['post_status'] = 1;
			$pwhere['post_id'] = $id;
			$cdata['post'] = $this->m_posts->getJoin($pwhere);
			
			$data = $this->_header($cdata);
			$data['title'] = 'IA TASS'.$cdata['post']->post_title;
			$data['content'] = $this->load->view('default/v_single_static',$cdata,TRUE);
			$this->load->view('default/v_body.php',$data);
		}
	}
	public function gallery(){
		$this->load->model('m_media');
		$this->load->library('pagination');
		$this->load->helper('base_value');
		/*---------------------------------------------------------------
		Begin pagination Post
		*/
			$pwhere['media_status'] = 1;
			$pwhere['media_gallery'] = 1;
		$config = paginationHTML();
		$config['base_url'] = site_url('home/gallery');
		$config['total_rows'] = $this->m_media->select($pwhere)->num_rows();
		$config['per_page'] = 20;
		$config['display_pages'] = FALSE;
		$config['uri_segment'] = 3;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$cdata['media'] = $this->m_media->getPage($config['per_page'],$page,$pwhere);
		$cdata['media_link'] = $this->pagination->create_links();
		$cdata['media_offset'] = $page;
		/*---------------------------------------------------------------
		END pagination Post
		*/
		
		$data = $this->_header($cdata);
		$data['title'] = 'IA TASS - Gallery';
		$data['content'] = $this->load->view('default/v_gallery',$cdata,TRUE);
		$this->load->view('default/v_body.php',$data);
	}
	function addSubscribe(){
		if($_POST){
			$this->load->model('m_users');
			$users['user_username'] = 'subscriber';
			$users['user_password'] = 'subscriber';
			$users['user_email'] = $this->input->post('uEmail');
			$users['user_name'] = 'subscriber';
			$users['user_status'] = 1;
			$users['user_group'] = 4;
			$this->m_users->add($users);
			$this->session->set_flashdata('notice','Terima kasih, email anda sudah tersimpan');
			redirect(site_url('home'),'refresh');
		}else{
			$this->session->set_flashdata('notice','Page not found');
			redirect(site_url('home'),'refresh');
		}
	}
	function deleteSubscribe(){
		if($_POST){
			$this->session->set_flashdata('notice','Come back latter');
		}else{
			$this->session->set_flashdata('notice','Page not found');
			redirect(site_url('home'),'refresh');
		}
	}
	function dataAlumni(){
		$data = $this->_header();
		$data['content'] = $this->load->view('default/v_page_alumni',NULL,TRUE);
		$this->load->view('default/v_body.php',$data);
	}
	function searchAlumni($q=NULL){
		$this->load->model('m_alumni');
		$this->load->helper('base_value');
		$this->load->library('pagination');
		
		if(is_null($q)){
			$q = $this->input->get('q');
		}
		/*---------------------------------------------------------------
		Begin pagination Post
		*/
		$like['dba_name'] = urldecode($q);
		$config = paginationHTML();
		$config['base_url'] = site_url('home/searchAlumni/'.$q.'/');
		$config['total_rows'] = $this->m_alumni->selectLike($like)->num_rows();
		$config['per_page'] = 20;
		$config['uri_segment'] = 4;
		$this->pagination->initialize($config); 
		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		
		$cdata['alumni'] = $this->m_alumni->getPageLike($config['per_page'],$page,$like);
		$cdata['page_link'] = $this->pagination->create_links();
		$cdata['page_offset'] = $page;
		$cdata['page_total'] = $config['total_rows'];
		$cdata['searchq'] = urldecode($q);
		/*---------------------------------------------------------------
		END pagination Post
		*/
		$data = $this->_header();
		$data['content'] = $this->load->view('default/v_page_alumni',$cdata,TRUE);
		$this->load->view('default/v_body.php',$data);
	}
}

/* End of file home.php */
/* Location: ./application/controllers/home.php */