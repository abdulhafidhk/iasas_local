<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title">
			<i class="fa fa-list"></i> Data Alumni
		</div>
	</div>
	<div class="panel-body">
		<div id="loading">
		</div>
		<?php $this->load->view('admin/_notice');?>
		<form action="<?php echo site_url('iaadmin/uploadDataAlumni/')?>" class="form" rule="form" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label>Upload csv</label>
				<div class="input-group">
					<input type="file" name="ifile" class="form-control" accept=".csv">
					<span class="input-group-btn">
						<button id="uploaded" class="btn btn-success" type="submit"><i class="fa fa-upload"></i> upload</button>
					</span>
				</div>
			</div>
			<div class="form-group">
				<label>Set delimiter</label>
				<div class="input-group">
					<div class="input-group col-md-4">
					<input type="text" name="delimiter" class="form-control" value=";">
				</div>
				</div>
			</div>
		</form>
		<div class="alert alert-danger">
			<i class="fa fa-info-cicle"></i> Rule:
			<ul>
				<li>kolom csv harus sesuai, ([NIM][program study][name][yudisium date][phone][email][address][extra])</li>
				<li>Extension .csv </li>
				<li>Jangan lupa set delimiter</li>
				<li>jika dari excel, save as csv. pastikan file haya berisi daftar alumni tanpa nama kolom atau lainnya.</li>
				<li>max size <b>10MB</b></li>
				<li>kolom extra akan menyimpan sisa data lainnya.</li>
			</ul>
		</div>
		<h2 class="title">DAFTAR ALUMNI</h2>
		<?php echo $page_link;?>
		<table class="table">
		<thead>
			<tr>
				<th colspan="2">
					Total: <?php echo $page_total;?> 
				</th>
				<th colspan="3">
					<button class="btn btn-success" title="view" data-toggle="modal" data-target="#addAlumni"><i class="fa fa-plus"></i> Add Alumni</button>
				</th>
				<th colspan="2">
					<form action="<?php echo site_url('iaadmin/searchAlumni');?>" class="form-inline" method="GET">
						<div class="form-group">
						<input type="text" name="q" class="form-control" placeholder="search name">
						<button type="submit" class="btn btn-primary" ><i class="fa fa-search"></i></button>
						</div>
					</form>
				<?php echo (isset($searchq))?'Search: '.$searchq:'';?>
				</th>
			</tr>
			<tr>
				<th>#</th>
				<th>NIM</th>
				<th>NAMA</th>
				<th>PRGORAM</th>
				<th>YUDISIUM</th>
				<th>PHONE</th>
				<th>EMAIL</th>
				<th>ACT</th>
			</tr>
		</thead>
		<tbody>
			<?php if($alumni):foreach($alumni->result() as $row):?>
			<tr>
				<td><?php echo ++$page_offset?></td>
				<td><?php echo $row->dba_nim?></td>
				<td><?php echo $row->dba_name?></td>
				<td><?php echo $row->dba_program?></td>
				<td><?php echo $row->dba_yudisium?></td>
				<td>+62<?php echo $row->dba_phone?></td>
				<td><?php echo $row->dba_email?></td>
				<td>
					<div class="btn-group">
						<a class="btn btn-danger delete-btn" href="<?php echo site_url('iaadmin/deleteAlumni/'.$row->dba_id)?>"><i class="fa fa-times"></i></a>
					</div>
				</td>
			</tr>
			<?php endforeach;endif;?>
		</tbody>
		</table>
		<?php echo $page_link;?>
	</div>
</div>
<!-- Modal -->
	<div class="modal fade" id="addAlumni" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Alumni</h4>
				</div>
				<div class="modal-body">
				<form action="<?php echo site_url('iaadmin/addAlumni/');?>" class="form-horizontal" rule="form" method="POST">
					<div class="form-group">
						<label class="col-sm-2 control-label">NIM</label>
						<div class="col-sm-6">
							<input type="text" name="dba_nim" class="form-control" placeholder="NIM" autocomplete="off" value="">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama</label>
						<div class="col-sm-6">
							<input type="text" name="dba_name" class="form-control" placeholder="nama" autocomplete="off" value="">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Program</label>
						<div class="col-sm-6">
							<input type="text" name="dba_program" class="form-control" placeholder="program" autocomplete="off" value="">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Yudisium</label>
						<div class="col-sm-6">
							<input type="text" id="dba_yudisium_date" name="dba_yudisium" class="form-control" placeholder="yudisium" autocomplete="off" value="">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Phone</label>
						<div class="col-sm-6">
							<input type="text" name="dba_phone" class="form-control" placeholder="phone" autocomplete="off" value="">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Email</label>
						<div class="col-sm-6">
							<input type="email" name="dba_email" class="form-control" placeholder="Email" autocomplete="off" value="">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Alamat</label>
						<div class="col-sm-6">
							<input type="text" name="dba_address" class="form-control" placeholder="alamat" autocomplete="off" value="">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Extra</label>
						<div class="col-sm-6">
							<input type="text" name="dba_extra" class="form-control" placeholder="Keterangan" autocomplete="off" value="">
						</div>
					</div>
					<button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Add</button>
				</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
<script>
	$(document).ready(function(){
		$('#uploaded').on('click',function(ev){
			$('#loading').html('<div class="alert alert-success"><img src="<?php base_url('assets/images/spiffygif_30x30.gif');?>">  Uploading</div>');
		});
		$('.delete-btn').click(function(e){
			var con = confirm('Apakah anda yakin ingin menghapus data ini?');
			if(con){
				return true;
			}else{
				return false;
			}
		});
		$('#dba_yudisium_date').datepicker({
			dateFormat: 'dd-mm-yy'
		});
	});
</script>