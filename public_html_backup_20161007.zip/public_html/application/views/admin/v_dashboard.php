<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title">
			<i class="fa fa-pie-chart"></i> Dashboard
		</div>
	</div>
	<div class="panel-body">
		<?php $this->load->view('admin/_notice');?>
		<div class="btn-group">
			<a class="btn btn-success" href="<?php echo site_url('iaadmin/addPost/');?>">Add post</a>
			<a class="btn btn-success" href="<?php echo site_url('iaadmin/post/');?>">Add category</a>
			<a class="btn btn-success" href="<?php echo site_url('iaadmin/post/');?>">Add media</a>
		</div>
		<div class="btn-group">
			<a class="btn btn-warning" href="<?php echo site_url('iaadmin/addEvent/');?>">Add Event</a>
			<a class="btn btn-warning" href="<?php echo site_url('iaadmin/event/');?>">All Events</a>
		</div>
		<hr/>
		<table class="table table-striped">
			<tr>
				<td>Total User</td>
				<td><?php echo $users?></td>
			</tr>
			<tr>
				<td>Total Post</td>
				<td><?php echo $posts?></td>
			</tr>
			<tr>
				<td>Total Event</td>
				<td><?php echo $events?></td>
			</tr>
			<tr>
				<td>Total Media</td>
				<td><?php echo $media?></td>
			</tr>
			
		</table>
		<!-- Step 1: Create the containing elements. -->

		<section id="auth-button"></section>
		<section id="view-selector"></section>
		<section id="timeline"></section>
		<div class="row">
			<div class="col-md-6">
				<section id="browser"></section>
			</div>
			<div class="col-md-6">
				<section id="os"></section>
			</div>
			
		</div>

		<!-- Step 2: Load the library. -->
		<script src="https://apis.google.com/js/client:platform.js" async defer></script>
		<script>
		(function(w,d,s,g,js,fjs){
		  g=w.gapi||(w.gapi={});g.analytics={q:[],ready:function(cb){this.q.push(cb)}};
		  js=d.createElement(s);fjs=d.getElementsByTagName(s)[0];
		  js.src='https://apis.google.com/js/platform.js';
		  fjs.parentNode.insertBefore(js,fjs);js.onload=function(){g.load('analytics')};
		}(window,document,'script'));
		</script>

		<script>
		gapi.analytics.ready(function() {

		  // Step 3: Authorize the user.

		  var CLIENT_ID = '769124904441-gqk7he2otnpb45a1q5639ebubm2dh55g.apps.googleusercontent.com';

		  gapi.analytics.auth.authorize({
			container: 'auth-button',
			clientid: CLIENT_ID,
		  });

		  // Step 4: Create the view selector.

		  var viewSelector = new gapi.analytics.ViewSelector({
			container: 'view-selector'
		  });
		  console.log(JSON.stringify(viewSelector));
		  // Step 5: Create the timeline chart.

		  var timeline = new gapi.analytics.googleCharts.DataChart({
			reportType: 'ga',
			query: {
			  'dimensions': 'ga:date',
			  'metrics': 'ga:sessions,ga:pageviews,ga:visitors',
			  'start-date': '30daysAgo',
			  'end-date': 'yesterday',
			},
			chart: {
			  type: 'LINE',
			  container: 'timeline',
			  options: {
				width: '100%',
				title: 'IAPolitel Visitor',
				colors: ['#ff8080', '#80ff80', '#8080ff', '#abcdef', '#f6c7b6']
				}
			}
		  });
		  
		  var browser = new gapi.analytics.googleCharts.DataChart({
			reportType: 'ga',
			query: {
			  'dimensions': 'ga:browser',
			  'metrics': 'ga:sessions',
			  'start-date': '30daysAgo',
			  'end-date': 'yesterday',
			},
			chart: {
			  type: 'PIE',
			  container: 'browser',
			  title: 'Browser Visitor',
			  colors: ['#ff8080', '#80ff80', '#8080ff', '#abcdef', '#f6c7b6']
			}
		  });
		  
		  var os = new gapi.analytics.googleCharts.DataChart({
			reportType: 'ga',
			query: {
			  'dimensions': 'ga:operatingSystem',
			  'metrics': 'ga:sessions',
			  'start-date': '30daysAgo',
			  'end-date': 'yesterday',
			},
			chart: {
			  type: 'PIE',
			  container: 'os',
			  title: 'OS Visitor',
			  colors: ['#ff8080', '#80ff80', '#8080ff', '#abcdef', '#f6c7b6']
			}
		  });
		  
		  
		  // Step 6: Hook up the components to work together.

		  gapi.analytics.auth.on('success', function(response) {
			viewSelector.execute();
		  });

		  viewSelector.on('change', function(ids) {
			var newIds = {
			  query: {
				ids: ids
			  }
			}
			timeline.set(newIds).execute();
			browser.set(newIds).execute();
			os.set(newIds).execute();
		  });
		});
		</script>
	</div>
</div>