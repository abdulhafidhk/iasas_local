<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title"><i class="fa fa-users"></i> Users</div>
	</div>
	<div class="panel-body">
		<?php $this->load->view('admin/_notice');?>
		<div class="row">
			<div class="col-md-6">
				<h2 class="title">Profile</h2>
				<table class="table table-striped">
					<tr>
						<th>ID</th>
						<td><?php echo $admin->user_id?></td>
					</tr>
					<tr>
						<th>Username</th>
						<td><?php echo $admin->user_username?></td>
					</tr>
					<tr>
						<th>Name</th>
						<td><?php echo $admin->user_name?></td>
					</tr>
					<tr>
						<th>Email</th>
						<td><?php echo $admin->user_email?></td>
					</tr>
					<tr>
						<th>Status</th>
						<td><?php echo getUserStatus($admin->user_status)?></td>
					</tr>
					<tr>
						<th>Group</th>
						<td><?php echo $group[$admin->user_group-1]->ug_name?></td>
					</tr>
					
				</table>
			</div>
			<div class="col-md-6">
				<h2 class="title">Update profile</h2>
				<form action="<?php echo site_url('iaadmin/updateUser/');?>" class="form-horizontal" method="POST">
					<div class="form-group">
						<label class="col-sm-2 control-label">Password</label>
						<div class="col-sm-10">
							<input type="text" id="upass" name="ipassword" class="form-control" placeholder="password" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Confirm Password</label>
						<div class="col-sm-10">
							<input type="password" id="ucpass" name="icpassword" class="form-control" placeholder="password" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Old Password</label>
						<div class="col-sm-10">
							<input type="password" id="oldpass" name="oldpassword" class="form-control" placeholder="old password" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								<input type="checkbox" id="readyUpdate" aria-label="check"> Check for update
							</span>
							<div class="input-group-btn">
								<button id="updateButton" type="submit" class="btn btn-success" disabled><i class="fa fa-save"></i> Update</button>
								<div id="urandom" class="btn btn-warning"><span class="fa fa-asterisk"></span> Random Password</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		<h2 class="title">User List</h2>
		<?php if($users->num_rows()>0):?>
		<table class="table" id="userTable">
			<thead>
				<tr>
					<th>#</th>
					<th>username</th>
					<th>name</th>
					<th>email</th>
					<th>status</th>
					<th>group</th>
					<th>action</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($users->result() as $row):?>
				<tr>
					<td><?php echo $row->user_id?></td>
					<td><?php echo $row->user_username?></td>
					<td><?php echo $row->user_name?></td>
					<td><?php echo $row->user_email?></td>
					<td><?php echo getUserStatus($row->user_status)?></td>
					<td><?php echo $group[$row->user_group-1]->ug_name?></td>
					<td>
						<?php if($row->user_group<=2):?>
							-
						<?php else:?>
							<?php if($row->user_status==1):?>
								<a class="btn btn-danger" href="#"><i class="fa fa-minus-circle"></i> Ban</a>
							<?php else:?>
								<a class="btn btn-danger" href="#"><i class="fa fa-minus-recycle"></i> Ban</a>
							<?php endif;?>
						<?php endif;?>
					</td>
				</tr>
				<?php endforeach;?>
			</tbody>
		</table>
		<?php else:?>
		<div class="well">
			Empty
		</div>
		<?php endif;?>
		<div class="row">
			<div class="col-md-6">
				<h2 class="title">Add User</h2>
				<form action="<?php echo site_url('iaadmin/saveUser/');?>" class="form-horizontal" method="POST">
					<div class="form-group">
						<div class="col-sm-10">
							<input type="text" class="form-control" name="iusername" placeholder="username">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-10">
						<input type="text" class="form-control" name="iname" placeholder="name">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-10">
						<input type="email" class="form-control" name="iemail" placeholder="email">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-10">
						<select class="form-control" name="iuserGroup">
							<?php $i=TRUE;foreach($usergroup->result() as $row):?>
								<?php if($i==TRUE){$i=FALSE;continue;}?>
								<option value="<?php echo $row->ug_id?>"><?php echo $row->ug_name?></option>
							<?php endforeach;?>
						</select>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-10">
						<input id="pass" type="text" class="form-control " name="ipassword" placeholder="password" autocomplete="off">
						<input id="cpass" type="password" class="form-control " name="icpassword" placeholder="confirm" autocomplete="off">
						</div>
					</div>
					<div id="random" class="btn btn-warning"><span class="fa fa-asterisk"></span> Random Password</div>
					<button class="btn btn-primary" type="submit"><span class="fa fa-plus"></span> add User</button>
				</form>
			</div>
			<div class="col-md-6">
				<h2 class="title">User Group</h2>
				<table class="table table-striped">
					<tr>
						<th>#</th>
						<th>Name</th>
						<th>Description</th>
					</tr>
					<?php foreach($usergroup->result() as $row):?>
					<tr>
						<td><?php echo $row->ug_id;?></td>
						<td><?php echo $row->ug_name?></td>
						<td><?php echo $row->ug_desc?></td>
					</tr>
					<?php endforeach;?>
					
				</table>
			</div>
		</div>
		
		
		<script>
		$(document).ready(function(){
			$('#userTable').dataTable({
				"sDom": '<"top"f>rt<"bottom"ip><"clear">'
			});
			$('#random').click(function(){
				var val = createRandomKey(8);
				$("#pass").val(val);
				$("#cpass").focus();
			});
			$('#urandom').click(function(){
				var val = createRandomKey(8);
				$("#upass").val(val);
				$("#ucpass").focus();
			});
			$('#readyUpdate').on('change',function(){
				$("#updateButton").prop('disabled',!this.checked);
			});
		});
		function createRandomKey(amount)
		{
			var text = "";
			var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

			for( var i=0; i < amount; i++ )
				text += possible.charAt(Math.floor(Math.random() * possible.length));

			return text;
		}
	</script>
	</div>
</div>