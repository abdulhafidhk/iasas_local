<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title"><i class="fa fa-gear"></i> Config</div>
	</div>
	<div class="panel-body">
		<?php $this->load->view('admin/_notice');?>
		<h2 class="title">Config</h2>
		<form action="<?php echo site_url('config/save');?>" class="form-horizontal" rule="form" method="POST">
			<div class="form-group">
				<label class="col-sm-2"><?php echo $config[0]->option_name?></label>
				<div class="col-sm-6">
					<input type="text" name="iwebTitle" class="form-control" placeholder="title" autocomplete="off" value="<?php echo $config[0]->option_value?>">
					<p class="help-block"><?php echo $config[0]->option_desc?></p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2"><?php echo $config[1]->option_name?></label>
				<div class="col-sm-6">
					<input type="text" name="iaddress" class="form-control" placeholder="title" autocomplete="off" value="<?php echo $config[1]->option_value?>">
					<p class="help-block"><?php echo $config[1]->option_desc?></p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2"><?php echo $config[2]->option_name?></label>
				<div class="col-sm-6">
					<input type="text" name="iwebEmail" class="form-control" placeholder="title" autocomplete="off" value="<?php echo $config[2]->option_value?>">
					<p class="help-block"><?php echo $config[2]->option_desc?></p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2"><?php echo $config[3]->option_name?></label>
				<div class="col-sm-6">
					<input type="text" name="iPhone" class="form-control" placeholder="title" autocomplete="off" value="<?php echo $config[3]->option_value?>">
					<p class="help-block"><?php echo $config[3]->option_desc?></p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2"><?php echo $config[4]->option_name?></label>
				<div class="col-sm-6">
					<input type="text" name="iChat" class="form-control" placeholder="title" autocomplete="off" value="<?php echo $config[4]->option_value?>">
					<p class="help-block"><?php echo $config[4]->option_desc?></p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2"><?php echo $config[5]->option_name?></label>
				<div class="col-sm-6">
					<input type="text" name="iFacebook" class="form-control" placeholder="title" autocomplete="off" value="<?php echo $config[5]->option_value?>">
					<p class="help-block"><?php echo $config[5]->option_desc?></p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2"><?php echo $config[6]->option_name?></label>
				<div class="col-sm-6">
					<input type="text" name="iTwitter" class="form-control" placeholder="title" autocomplete="off" value="<?php echo $config[6]->option_value?>">
					<p class="help-block"><?php echo $config[6]->option_desc?></p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2"><?php echo $config[7]->option_name?></label>
				<div class="col-sm-6">
					<input type="text" name="iGoogle" class="form-control" placeholder="title" autocomplete="off" value="<?php echo $config[7]->option_value?>">
					<p class="help-block"><?php echo $config[7]->option_desc?></p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2"><?php echo $config[8]->option_name?></label>
				<div class="col-sm-8">
					<textarea class="form-control" name="iProfile" style="overflow-y:scroll;height:300px;"><?php echo $config[8]->option_value?></textarea>
					<p class="help-block"><?php echo $config[8]->option_desc?></p>
				</div>
			</div>
			<button class="btn btn-success btn-lg" type="submit"><i class="fa fa-save"></i> Save</button>
		</form>
	</div>
</div>