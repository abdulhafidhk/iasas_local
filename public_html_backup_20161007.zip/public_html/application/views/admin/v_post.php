<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title">
			<i class="fa fa-newspaper-o"></i> Post
		</div>
	</div>
	<div class="panel-body">
		<?php $this->load->view('admin/_notice');?>
		<h2 class="title">Post</h2>
		<form action="<?php echo site_url('iaadmin/searchPost/');?>" class="form" method="POST">
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-btn">
						<a class="btn btn-success" href="<?php echo site_url('iaadmin/addPost');?>"><i class="fa fa-plus"></i> New Post</a>
					</span>
					<span class="input-group-addon">Total Post <?php echo $post_total;?></span>
					<input type="text" class="form-control" name="psearch" placeholder="Search post">
					<span class="input-group-btn">
						<button class="btn btn-primary" type="submit"><span class="fa fa-search"></span> Search post</button>
					</span>
				</div>
			</div>
		</form>
		<table class="table table-striped">
			<thead>
			<tr>
				<th>IDs</th>
				<th>Title</th>
				<th>Created</th>
				<th>Type</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if($posts->num_rows()>0):?>
			<?php foreach($posts->result() as $row):?>
			<tr style="background:<?php echo ($row->post_status==0)?'#ff8080':'#fff';?>">
				<td><?php echo $row->post_id;?></td>
				<td><?php echo $row->post_title;?></td>
				<td><?php echo date('d-m-Y H:i:s',$row->post_date);?></td>
				<td><?php echo getPostType($row->post_type);?></td>
				<td><?php echo getPostStatus($row->post_status);?></td>
				<td>
					<div class="btn-group">
						<?php if($row->post_status == 0):?>
							<a class="btn btn-sm btn-danger" href="<?php echo site_url('iaadmin/dropPost/'.$row->post_id)?>" title="permanen delete"><i class="fa fa-times"></i></a>
							<a class="btn btn-sm btn-success" href="<?php echo site_url('iaadmin/restorePost/'.$row->post_id)?>" title="restore"><i class="fa fa-recycle"></i></a>
						<?php else:?>
							<a class="btn btn-sm btn-danger" href="<?php echo site_url('iaadmin/deletePost/'.$row->post_id)?>" title="delete"><i class="fa fa-times"></i></a>
							<a class="btn btn-sm btn-default" href="<?php echo site_url('iaadmin/editPost/'.$row->post_id)?>" title="edit"><i class="fa fa-pencil"></i></a>
							<a class="btn btn-sm btn-default" target="_blank" href="<?php echo site_url('home/post/'.$row->post_id)?>" title="view on web"><i class="fa fa-file"></i></a>
						<?php endif;?>
					</div>
				</td>
			</tr>
			<?php endforeach;?>
			<?php else:?>
			<tr>
				<td colspan="6">No posts record</td>
			</tr>	
			<?php endif;?>
			</tbody>
		</table>
		<?php if($posts->num_rows()>0):?>
			<?php echo $post_link;?>
		<?php endif;?>
		<hr/>
		<h2 class="title">Category</h2>
		<div class="row">
			<div class="col-md-8">
				<?php $i=1;if($category->num_rows()>0):?>
				<table id="catTable" class="table">
					<thead>
					<tr>
						<th>#</th>
						<th width="250px">Category</th>
						<th width="50px">Active?</th>
						<th>Action</th>
					</tr>
					</thead>
					<tbody>
					<?php foreach($category->result() as $row):?>
					<tr>
						<td><?php echo $i++;?></td>
						<td><?php echo $row->category_name;?></td>
						<td><?php echo getCategoryStatus($row->category_status);?></td>
						<td>
							<div class="btn-group">
								<?php if($row->category_status == 0):?>
									<a class="btn btn-sm btn-success" href="<?php echo site_url('iaadmin/restoreCategory/'.$row->category_id)?>" title="active"><i class="fa fa-recycle"></i></a>
								<?php else:?>
									<a class="btn btn-sm btn-danger" href="<?php echo site_url('iaadmin/deleteCategory/'.$row->category_id)?>" title="delete"><i class="fa fa-times"></i></a>
								<?php endif;?>
							</div>
						</td>
					</tr>
					<?php endforeach;?>
					</tbody>
				</table>
				<?php else:?>
				<div class="well">No category record</div>
				<?php endif;?>
			</div>
			<div class="col-md-4">
			<form action="<?php echo site_url('iaadmin/saveCategory/')?>" class="form" rule="form" method="post">
				<div class="form-group">
					<label>Add new category</label>
					<div class="input-group">
						<input type="text" name="icategory" class="form-control" placeholder="category name">
						<span class="input-group-btn">
							<button class="btn btn-success" type="submit"><i class="fa fa-plus"></i> Add</button>
						</span>
					</div>
				</div>
			</form>
			</div>
		</div>
		<h2 class="title">Media</h2>
		<div class="alert alert-danger">
		<form action="<?php echo site_url('iaadmin/uploadMedia/')?>" class="form" rule="form" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label>Upload new Media</label>
				<div class="input-group">
					<span class="input-group-addon">
						<input type="checkbox" aria-label="gallery" name="igallery"  value="1" > Show in gallery?
					</span>
					<input type="file" name="ifile" class="form-control" accept="image/*">
					<span class="input-group-btn">
						<button class="btn btn-success" type="submit"><i class="fa fa-plus"></i> upload</button>
					</span>
				</div>
			</div>
		</form>
			<i class="fa fa-info-cicle"></i> Rule:
			<ul>
				<li><b>Check</b> untuk menampilkan di halaman gallery.</li>
				<li>Extension <b>jpg</b>, <b>png</b>, <b>gif</b></li>
				<li>max size <b>5MB</b></li>
				<li>width &amp; height not limited</li>
			</ul>
		</div>
		<?php $i=1;if($media->num_rows()>0):?>
			<table id="mediaTable" class="table">
				<thead>
				<tr>
					<th>#</th>
					<th>Name</th>
					<th>URL</th>
					<th>Status</th>
					<th>Show Gallery</th>
					<th>Action</th>
				</tr>
				</thead>
				<tbody>
				<?php foreach($media->result() as $row):?>
				<tr style="background:<?php echo ($row->media_status==0)?'#ff8080':'#fff';?>">
					<td><?php echo $row->media_id;?></td>
					<td><?php echo $row->media_realname;?></td>
					<td><a class="copyText" title="copy"><?php echo $row->media_url;?></a></td>
					<td><?php echo getMediaStatus($row->media_status);?></td>
					<td><?php echo ($row->media_gallery==1)?'<span class="label label-success">Y</span>':'<span class="label label-warning">N</span>';?></td>
					<td>
						<div class="btn-group">
							<?php if($row->media_status == 1):?>
								<a class="btn btn-sm btn-danger" href="<?php echo site_url('iaadmin/deleteMedia/'.$row->media_id)?>" title="delete"><i class="fa fa-times"></i></a>
							<?php else:?>
								<a class="btn btn-sm btn-danger" href="<?php echo site_url('iaadmin/dropMedia/'.$row->media_id)?>" title="permanent delete"><i class="fa fa-times"></i></a>
								<a class="btn btn-sm btn-success" href="<?php echo site_url('iaadmin/restoreMedia/'.$row->media_id)?>" title="active"><i class="fa fa-recycle"></i></a>
							<?php endif;?>
							<button class="btn btn-sm btn-default btn-load-image" title="view" data-toggle="modal" data-target="#myModal" data-url="<?php echo base_url($row->media_url)?>">
								<i class="fa fa-image"></i>
							</button>
						</div>
					</td>
				</tr>
				<?php endforeach;?>
				</tbody>
			</table>
			<?php else:?>
			<div class="well">No media record</div>
			<?php endif;?>
	</div>

	<!-- Modal -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Image</h4>
		  </div>
		  <div class="modal-body">
			<div id="modal-image"></div>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  </div>
		</div>
	  </div>
	</div>
</div>
	<script>
		$(document).ready(function() {
			$('#catTable').dataTable( {
				"sDom": '<"top"f>rt<"bottom"ip><"clear">'
			} );
			$('#mediaTable').dataTable( {
				"order": [[3,"asc"],[ 0, "desc" ]],
				"sDom": '<"top"f>rt<"bottom"ip><"clear">'
			} );
			$('.copyText').click(function(e){
				var text = '<?php echo base_url()?>'+$(this).text();
				window.prompt("Copy to clipboard: Ctrl+C, Enter", text);
			});
			$('.btn-load-image').click(function(e){
				var url = $(this).attr('data-url');
				$('#modal-image').html('<img class="img" src='+url+'>');
				// return false;
				// e.preventDefault();
			});
		} );
	</script>