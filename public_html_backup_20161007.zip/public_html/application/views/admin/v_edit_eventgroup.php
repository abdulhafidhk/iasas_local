<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title"><i class="fa fa-calendar"></i> Events / Add Event</div>
	</div>
	<div class="panel-body">
		<form action="<?php echo site_url('iaadmin/updateEventgroup');?>" class="form-horizontal" method="POST">
			<input type="hidden" name="egId" class="form-control" placeholder="name" autocomplete="off" value="<?php echo $eventgroup->eg_id?>">
			<div class="form-group">
				<label class="col-sm-2 control-label">Eventgroup name</label>
				<div class="col-sm-6">
					<input type="text" name="egName" class="form-control" placeholder="name" autocomplete="off" value="<?php echo $eventgroup->eg_name?>">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Eventgroup Description</label>
				<div class="col-sm-6">
					<input type="text" name="egDesc" class="form-control" placeholder="description" autocomplete="off" value="<?php echo $eventgroup->eg_desc?>">
				</div>
			</div>
			
			<div class="form-group">
				<div class="col-sm-6">
					<button class="btn btn-success" type="submit"><i class="fa fa-save"></i> Update</button>
				</div>
			</div>
		</form>
		
		<!-- Disable
		
		-->
		<script>
			$(document).ready(function(){
				
			});
		</script>
	</div>
</div>