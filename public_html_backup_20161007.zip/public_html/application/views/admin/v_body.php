<?php $this->load->view('admin/v_header.php');?>
<body>
	<div class="container">
		<div id="admin-header">
			<img src="<?php echo base_url()?>assets/images/logo-80x80.png">
			<h2 class="pull-right">Admin Menu</h2>
		</div>
		<div id="admin-content">
			<div class="row">
				<div class="col-md-2">
					<div class="nav-admin">
						<ul>
							<li><a href="<?php echo base_url('home');?>"><i class="fa fa-desktop"></i> Visit web</a></li>
							<li class="<?php echo ($active==='dashboard')?'active':'';?>"><a href="<?php echo site_url('iaadmin');?>"><i class="fa fa-pie-chart"></i> Dashboard</a></li>
							<li class="<?php echo ($active==='post')?'active':'';?>"><a href="<?php echo site_url('iaadmin/post');?>"><i class="fa fa-newspaper-o"></i> Posts</a></li>
							<li class="<?php echo ($active==='event')?'active':'';?>"><a href="<?php echo site_url('iaadmin/event');?>"><i class="fa fa-calendar"></i> Events</a></li>
							<li class="<?php echo ($active==='newsletter')?'active':'';?>"><a href="<?php echo site_url('iaadmin/newsletter');?>"><i class="fa fa-envelope"></i> Newsletter</a></li>
							<?php if($this->session->userdata('user_group') <= 2):?>
							<li class="<?php echo ($active==='user')?'active':'';?>"><a href="<?php echo site_url('iaadmin/users');?>"><i class="fa fa-users"></i> Users</a></li>
							<li class="<?php echo ($active==='dbalumni')?'active':'';?>"><a href="<?php echo site_url('iaadmin/dbAlumni');?>"><i class="fa fa-list"></i> Data Alumni</a></li>
							<li class="<?php echo ($active==='menu')?'active':'';?>"><a href="<?php echo site_url('iaadmin/menu');?>"><i class="fa fa-bookmark"></i> Menu</a></li>
							<li class="<?php echo ($active==='config')?'active':'';?>"><a href="<?php echo site_url('config');?>"><i class="fa fa-gear"></i> Config</a></li>
							<?php endif;?>
							<li class="<?php echo ($active==='guide')?'active':'';?>"><a href="<?php echo site_url('iaadmin/guide');?>"><i class="fa fa-question-circle"></i> Guide</a></li>
							<li style="background:#d43f3a;" ><a href="<?php echo site_url('ia_login/logout');?>"><i class="fa fa-power-off"></i> Logout</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-10">
					<?php echo $content?>
				</div>
			</div>
		</div>
	</div>
</body>
</html>