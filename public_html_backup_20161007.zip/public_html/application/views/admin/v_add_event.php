<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title"><i class="fa fa-calendar"></i> Events / Add Event</div>
	</div>
	<div class="panel-body">
		<form action="<?php echo site_url('iaadmin/saveEvent');?>" class="form-horizontal" method="POST">
			<div class="form-group">
				<label class="col-sm-2 control-label">Event Title</label>
				<div class="col-sm-6">
					<input type="text" name="eventTitle" class="form-control" placeholder="title" autocomplete="off">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Event Date</label>
				<div class="col-sm-6">
					<input type="text" id="eventDate" name="eventDate" class="form-control" placeholder="date" autocomplete="off">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Event Group</label>
				<div class="col-sm-6">
					<select name="eventGroup" class="form-control">
						<?php foreach($eventgroup->result() as $row):?>
							<option value="<?php echo $row->eg_id?>"><?php echo $row->eg_name?></option>
						<?php endforeach;?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Event Content</label>
				<div class="col-sm-8">
					<textarea id="editor" class="form-control" name="eventContent" style="overflow-y:scroll;height:300px"></textarea>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Event Location</label>
				<div class="col-sm-6">
					<div class="input-group">
						<input type="text" id="eventLocation" name="eventLocation" class="form-control" placeholder="Loaction" autocomplete="off">
						<div class="input-group-btn">
							<div class="btn btn-default" data-toggle="modal" data-target="#mapModal"><i class="fa fa-map-marker"></i> Pick</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="col-sm-6">
					<button class="btn btn-success btn-lg" type="submit"><i class="fa fa-save"></i> Save</button>
				</div>
			</div>
		</form>
		
		<h2 class="title">Media</h2>
		<?php $i=1;if($media->num_rows()>0):?>
			<table id="mediaTable" class="table">
				<thead>
				<tr>
					<th>#</th>
					<th>Name</th>
					<th>URL</th>
					<th>Status</th>
					<th>Action</th>
				</tr>
				</thead>
				<tbody>
				<?php foreach($media->result() as $row):?>
				<tr>
					<td><?php echo $row->media_id;?></td>
					<td><?php echo $row->media_realname;?></td>
					<td><a class="copyText" title="copy"><?php echo $row->media_url;?></a></td>
					<td><?php echo getMediaStatus($row->media_status);?></td>
					<td>
						<div class="btn-group">
							<?php if($row->media_status == 1):?>
								<a class="btn btn-sm btn-danger" href="<?php echo site_url('iaadmin/deleteMedia/'.$row->media_id)?>" title="delete"><i class="fa fa-times"></i></a>
							<?php else:?>
								<a class="btn btn-sm btn-danger" href="<?php echo site_url('iaadmin/dropMedia/'.$row->media_id)?>" title="permanent delete"><i class="fa fa-times"></i></a>
								<a class="btn btn-sm btn-success" href="<?php echo site_url('iaadmin/restoreMedia/'.$row->media_id)?>" title="active"><i class="fa fa-recycle"></i></a>
							<?php endif;?>
							<button class="btn btn-sm btn-default btn-load-image" title="view" data-toggle="modal" data-target="#imageModal" data-url="<?php echo base_url($row->media_url)?>">
								<i class="fa fa-image"></i>
							</button>
						</div>
					</td>
				</tr>
				<?php endforeach;?>
				</tbody>
			</table>
			<?php else:?>
			<div class="well">No media record</div>
			<?php endif;?>
			
		<!-- Modal -->
		<div class="modal fade" id="mapModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Map</h4>
			  </div>
			  <div class="modal-body">
				<input type="text" id="searchAddress" class="form-control" placeholder="search address">
				<div id="maps" class="form-control" style="height:300px"></div>
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-map-marker"></i> Pick</button>
			  </div>
			</div>
		  </div>
		</div>
		<!-- image Modal -->
		<div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Image</h4>
			  </div>
			  <div class="modal-body">
				<div id="modal-image"></div>
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			  </div>
			</div>
		  </div>
		</div>
		<!-- Disable
		-->
		<script type="text/javascript" src='http://maps.google.com/maps/api/js?sensor=false&libraries=places'></script>
		<script type="text/javascript" src='<?php echo base_url()?>assets/js/locationpicker.jquery.min.js'></script>
		<script>
			$(document).ready(function(){
				$('#eventDate').datepicker({
					dateFormat: 'dd-mm-yy'
				});
				$('#editor').wysihtml5({
					color:false
				});
				$('#maps').locationpicker({
					location: {latitude: -6.2297465, longitude: 106.829518},
					radius:100,
					inputBinding: {
						locationNameInput: $('#searchAddress')
					},
					enableAutocomplete: true,
					onchanged: function (currentLocation, radius, isMarkerDropped) {
						$('#eventLocation').val(currentLocation.latitude+","+currentLocation.longitude);
					}
				});
				$('#mapModal').on('shown.bs.modal', function() {
					$('#maps').locationpicker('autosize');
				});
				$('.copyText').click(function(e){
					var text = '<?php echo base_url()?>'+$(this).text();
					window.prompt("Copy to clipboard: Ctrl+C, Enter", text);
				});
				$('.btn-load-image').click(function(e){
					var url = $(this).attr('data-url');
					$('#modal-image').html('<img class="img" src='+url+'>');
				});
			});
		</script>
	</div>
</div>