<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title;?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="<?php echo base_url('assets/images/logo-80x80.png')?>" />
	<!-- CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap-wysihtml5.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/main.css">
	<!-- JavaScript -->
	<script src="<?php echo base_url();?>assets/js/jquery-1.10.2.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery-ui.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/wysihtml5-0.3.0.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap3-wysihtml5.js"></script>
	<script src="<?php echo base_url();?>assets/js/main.js"></script>
</head>
