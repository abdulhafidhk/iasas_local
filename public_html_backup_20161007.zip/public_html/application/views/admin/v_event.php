<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title"><i class="fa fa-calendar"></i> Events</div>
	</div>
	<div class="panel-body">
		<?php $this->load->view('admin/_notice');?>
		<h2 class="title">Event Group</h2>
		<form action="" class="form-inline" rule="form" method="POST">
			<div class="form-group">
				<input type="text" class="form-control" name="egName" placeholder="name">
			</div>
			<div class="form-group">
				<div class="input-group">
					<input type="text" class="form-control" name="egDisc" placeholder="description">
					<div class="input-group-btn">
						<button class="btn btn-success" type="submit"><i class="fa fa-save"></i> Save</button>
					</div>
				</div>
			</div>
		</form>
		<?php if($eventgroup->num_rows() > 0):?>
		<table id="egTable" class="table">
			<thead>
				<tr>
					<th>#</th>
					<th>Event Group</th>
					<th>Deskripsi</th>
					<th>status</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
			<?php $i=1;foreach($eventgroup->result() as $row):?>
				<tr>
					<td><?php echo $i++?></td>
					<td><?php echo $row->eg_name?></td>
					<td><?php echo $row->eg_desc?></td>
					<td><?php echo getEgStatus($row->eg_status)?></td>
					<td>
						<div class="btn btn-group">
							<?php if($row->eg_status == 1):?>
								<a class="btn btn-danger" href="<?php echo base_url('iaadmin/eventgroupStatus/'.$row->eg_id.'/0')?>" title="delete"><i class="fa fa-times"></i> </a>
							<?php else:?>
								<a class="btn btn-success" href="<?php echo base_url('iaadmin/eventgroupStatus/'.$row->eg_id.'/1')?>" title="restore"><i class="fa fa-recycle"></i> </a>
							<?php endif;?>
							<a class="btn btn-default" href="<?php echo base_url('iaadmin/editEventgroup/'.$row->eg_id)?>" title="edit"><i class="fa fa-pencil"></i> </a>
						</div>
					</td>
				</tr>
			<?php endforeach;?>
			</tbody>
		</table>
		<?php else:?>
			<div class="well">
				Empty
			</div>
		<?php endif;?>
		<h2 class="title">Events</h2>
		<form action="<?php echo site_url('iaadmin/searchEvent/')?>" class="form" method="POST">
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-btn">
						<a class="btn btn-success" href="<?php echo site_url('iaadmin/addEvent');?>"><i class="fa fa-plus"></i> New event</a>
					</span>
					<span class="input-group-addon">Total event <?php echo $event_total;?></span>
					<input type="text" class="form-control" name="esearch" placeholder="Search event title">
					<span class="input-group-btn">
						<button class="btn btn-primary" type="submit"><span class="fa fa-search"></span> Search event</button>
					</span>
				</div>
			</div>
		</form>
		<table class="table">
			<thead>
				<tr>
					<th>#</th>
					<th>Title</th>
					<th>Group</th>
					<th>Date</th>
					<th>Location</th>
					<th>Status</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
			<?php if($events->num_rows()>0):?>
			<?php foreach($events->result() as $row):?>
			<?php $location = explode(',',$row->event_location);?>
				<tr style="background:<?php echo ($row->event_status==0)?'#ff8080':'#fff';?>">
					<td><?php echo $row->event_id?></td>
					<td><?php echo $row->event_title?></td>
					<td><?php echo $row->eg_name?></td>
					<td><?php echo date('M d, Y',$row->event_date)?></td>
					<td><a target="_blank" href="http://maps.google.com/?q=<?php echo $row->event_location;?>" title="google maps"><i class="fa fa-map-marker"></i> Location</a></td>
					<td><?php echo getEventStatus($row->event_status)?></td>
					<td>
						<div class="btn btn-group">
						<?php if($row->event_status == 0):?>
							<a class="btn btn-danger" href="<?php echo base_url('iaadmin/dropEvent/'.$row->event_id)?>" title="permanent delete"><i class="fa fa-times"></i></a>
							<a class="btn btn-success" href="<?php echo base_url('iaadmin/eventStatus/'.$row->event_id.'/1')?>" title="restore"><i class="fa fa-recycle"></i></a>
						<?php else:?>
							<a class="btn btn-danger" href="<?php echo base_url('iaadmin/eventStatus/'.$row->event_id.'/0')?>" title="delete"><i class="fa fa-times"></i></a>
							<?php if($row->event_status == 2):?>
							<a class="btn btn-success" href="<?php echo base_url('iaadmin/eventStatus/'.$row->event_id.'/1')?>" title="active"><i class="fa fa-check"></i></a>
							<?php else:?>
							<a class="btn btn-default" href="<?php echo base_url('iaadmin/eventStatus/'.$row->event_id.'/2')?>" title="cancel"><i class="fa fa-minus-circle"></i></a>
							<?php endif;?>
						<?php endif;?>
							<a class="btn btn-default" href="<?php echo base_url('iaadmin/editEvent/'.$row->event_id)?>" title="edit"><i class="fa fa-pencil"></i></a>
							<a class="btn btn-default" href="<?php echo base_url('home/events/')?>" target="_blank" title="view web"><i class="fa fa-file"></i></a>
						</div>
					</td>
				</tr>
			<?php endforeach;?>
			<div class="">
				<?php echo $event_link;?>
			</div>
			<?php else:?>
				<tr>
					<td colspan="6">
						Empty
					</td>
				</tr>
			<?php endif;?>
			</tbody>
		</table>
	</div>
	
	<script>
		$(document).ready(function(){
			$('#egTable').dataTable({
				"sDom": '<"top"f>rt<"bottom"ip><"clear">'
			});
		});
	</script>
</div>