<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title">
			<i class="fa fa-bookmark"></i> Menu
		</div>
	</div>
	<div class="panel-body">
		<?php $this->load->view('admin/_notice');?>
		
		<label>Home Url</label>
		<div class="input-group col-md-6">
			<span class="input-group-addon" id="basic-addon1">base_url</span>
			<input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1" value="home" disabled>
		</div>
		<hr/>
		<label>News Url</label>
		<div class="input-group col-md-6">
			<span class="input-group-addon" id="basic-addon1">base_url</span>
			<input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1" value="home/news" disabled>
		</div>
		<hr/>
		<label>Event Url</label>
		<div class="input-group col-md-6">
			<span class="input-group-addon" id="basic-addon1">base_url</span>
			<input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1" value="home/events" disabled>
		</div>
		<hr/>
		<label>Gallery Url</label>
		<div class="input-group col-md-6">
			<span class="input-group-addon" id="basic-addon1">base_url</span>
			<input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1" value="home/gallery" disabled>
		</div>
		<hr/>
		<h2 class="title">Update</h2>
		<form action="<?php echo site_url('config/saveMenu');?>" class="form-horizontal" rule="form" method="POST">
			<div class="form-group">
				<label class="col-sm-2 control-label">Visi &amp; Misi url</label>
				<div class="col-sm-6">
					<div class="input-group">
						<span class="input-group-addon" >Select post</span>
						<select class="form-control" name="urlOrg">
							<option value="#">-</option>
							<?php foreach($posts->result() as $row):?>
							<option value="<?php echo $row->post_id?>" <?php echo ($row->post_id==$option[9]->option_value)?'selected':'';?>><?php echo $row->post_title?></option>
							<?php endforeach;?>
						</select>
					</div>
					<p class="help-block">Pilih dari post tipe static. atau buat <a href="<?php echo site_url('iaadmin/addPost')?>">post</a> baru.</p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Program Kerja</label>
				<div class="col-sm-6">
					<div class="input-group">
						<span class="input-group-addon" >Select post</span>
						<select class="form-control" name="urlVisimisi">
							<option value="#">-</option>
							<?php foreach($posts->result() as $row):?>
							<option value="<?php echo $row->post_id?>" <?php echo ($row->post_id==$option[10]->option_value)?'selected':'';?>><?php echo $row->post_title?></option>
							<?php endforeach;?>
						</select>
					</div>
					<p class="help-block">Pilih dari post tipe static. atau buat <a href="<?php echo site_url('iaadmin/addPost')?>">post</a> baru.</p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Struktur url</label>
				<div class="col-sm-6">
					<div class="input-group">
						<span class="input-group-addon" >Select post</span>
						<select class="form-control" name="urlStruktur">
							<option value="#">-</option>
							<?php foreach($posts->result() as $row):?>
							<option value="<?php echo $row->post_id?>" <?php echo ($row->post_id==$option[11]->option_value)?'selected':'';?>><?php echo $row->post_title?></option>
							<?php endforeach;?>
						</select>
					</div>
					<p class="help-block">Pilih dari post tipe static. atau buat <a href="<?php echo site_url('iaadmin/addPost')?>">post</a> baru.</p>
				</div>
			</div>
			<button class="btn btn-success" type="submit"><i class="fa fa-save"></i> Save</button>
		</form>
		
		<h2 class="title">Add Menu</h2>
		<form action="<?php echo site_url('config/saveAddmenu');?>" class="form-horizontal" rule="form" method="POST">
			<div class="form-group">
				<label class="col-sm-2 control-label">Menu</label>
				<div class="col-sm-10">
					<div class="input-group">
						<input type="text" class="form-control" name="iMenu" placeholder="name">
						<span class="input-group-addon" >
							<input type="radio" id="cek" name="check" value="post" checked>
						</span>
						<select id="inputPost" class="form-control" name="urlMenu"> Post
							<option value="#">-</option>
							<?php foreach($posts->result() as $row):?>
							<option value="<?php echo $row->post_id?>" ><?php echo $row->post_title?></option>
							<?php endforeach;?>
						</select>
						<span class="input-group-addon" >
							<input type="radio" id="cek" name="check" value="url"> Link
						</span>
						<input type="text" id="inputUrl" class="form-control" name="urlLink" placeholder="http://link">
					</div>
					<p class="help-block">Pilih dari post tipe static. atau buat <a href="<?php echo site_url('iaadmin/addPost')?>">post</a> baru.</p>
					<button class="btn btn-success" type="submit"><i class="fa fa-plus"></i> add</button>
				</div>
			</div>
		</form>
		
		<h2 class="title">Add Submenu</h2>
		<form action="<?php echo site_url('config/saveSubmenu');?>" class="form-horizontal" rule="form" method="POST">
			<div class="form-group">
				<label class="col-sm-2 control-label">Menu</label>
				<div class="col-sm-10">
					<div class="input-group">
						<input type="text" class="form-control" name="iMenu" placeholder="name">
						<span class="input-group-addon" >
							Parent
						</span>
						<select class="form-control" name="iParent">
							<option value="#">-</option>
							<option value="m:home">Home</option>
							<option value="m:organisasi">Organisasi</option>
							<option value="m:news">News</option>
							<option value="m:events">Events</option>
							<option value="m:gallery">Gallery</option>
							<?php foreach($menu as $row):?>
							<option value="<?php echo $row->option_id?>" ><?php echo $row->option_name?></option>
							<?php endforeach;?>
						</select>
						<span class="input-group-addon" >
							<input type="radio" id="cekMenu" name="check" value="post"> Post
						</span>
						<select class="form-control" id="selMenu" name="urlMenu">
							<option value="#">-</option>
							<?php foreach($posts->result() as $row):?>
							<option value="<?php echo $row->post_id?>" ><?php echo $row->post_title?></option>
							<?php endforeach;?>
						</select>
						<span class="input-group-addon" >
							<input type="radio" id="cekMenu" name="check" value="url"> Link
						</span>
						<input type="text"  id="inpMenu"class="form-control" name="urlLink" placeholder="http://link">
					</div>
					<p class="help-block">Pilih dari post tipe static. atau buat <a href="<?php echo site_url('iaadmin/addPost')?>">post</a> baru.</p>
					<button class="btn btn-success" type="submit"><i class="fa fa-plus"></i> add</button>
				</div>
			</div>
		</form>
		
		<h2 class="title">Menu List</h2>
		<table class="table">
			<thead>
			<tr>
				<th>Name</th>
				<th>URL</th>
				<th>Parent?</th>
				<th>Act</th>
			</tr>
			</thead>
			<tbody>
			<?php $j=0;foreach($menu as $row):?>
			<tr>
				<td><?php echo $row->option_name?></td>
				<td><?php echo $row->option_value?></td>
				<td><?php echo $row->option_desc?></td>
				<td>
					<a href="<?php echo site_url('config/deleteMenus/'.$row->option_id);?>" class="btn btn-danger btn-sm"><i class="fa fa-times"></i></a>
					<button class="btn btn-sm btn-default updateMenu" title="view" data-toggle="modal" data-target="#editSubmenu" data-id="<?php echo $j?>"><i class="fa fa-pencil"></i></button>
				</td>
			</tr>
			<?php $j++;endforeach;?>
			<?php $i=0;foreach($submenu as $row):?>
			<tr>
				<td><?php echo $row->option_name?></td>
				<td><?php echo $row->option_value?></td>
				<td><?php echo $row->option_desc?></td>
				<td>
					<a href="<?php echo site_url('config/deleteMenus/'.$row->option_id);?>" class="btn btn-danger btn-sm"><i class="fa fa-times"></i></a>
					<button class="btn btn-sm btn-default updateSubmenu" title="view" data-toggle="modal" data-target="#editSubmenu" data-id="<?php echo $i?>"><i class="fa fa-pencil"></i></button>
				</td>
			</tr>
			<?php $i++;endforeach;?>
			</tbody>
		</table>
		<script>
			var dmenu = <?php echo json_encode($menu)?>;
			var dsubmenu = <?php echo json_encode($submenu)?>;
			$(document).ready(function(){
				$('#inputPost').focus(function(){
					$('#cek[value=post]').prop("checked", true);
				});
				$('#inputUrl').focus(function(){
					$('#cek[value=url]').prop("checked", true);
				});
				$('#selMenu').focus(function(){
					$('#cekMenu[value=post]').prop("checked", true);
				});
				$('#inpMenu').focus(function(){
					$('#cekMenu[value=url]').prop("checked", true);
				});
				$('.updateSubmenu').click(function(e){
					var index = $(this).attr('data-id');
					$('#option_id').val(dsubmenu[index].option_id);
					$('#option_name').val(dsubmenu[index].option_name);
					$('#option_desc').val(dsubmenu[index].option_desc);
					$('.option_value').val(dsubmenu[index].option_value.split('=')[1]);
					$('.option_value_l').val(dsubmenu[index].option_value);
				});
				
				$('.updateMenu').click(function(e){
					var index = $(this).attr('data-id');
					$('#option_id').val(dmenu[index].option_id);
					$('#option_name').val(dmenu[index].option_name);
					$('#option_desc').val(dmenu[index].option_desc);
					$('.option_value').val(dmenu[index].option_value.split('=')[1]);
					$('.option_value_l').val(dmenu[index].option_value);
				});
				
			});
		</script>
	</div>
</div>
<!-- edit Modal -->
<div class="modal fade" id="editSubmenu" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" style="width:800px;">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Image</h4>
			</div>
			<div class="modal-body">
				<form action="<?php echo site_url('config/updateMenu');?>" class="form-horizontal" rule="form" method="POST">
					<div class="form-group">
						<label class="col-sm-2 control-label">ID</label>
						<div class="col-sm-5">
							<input type="text" id="option_id" class="form-control" name="option_id" placeholder="id">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Menu</label>
						<div class="col-sm-10">
							<div class="input-group">
								<input type="text" id="option_name"class="form-control" name="option_name" placeholder="name">
								<span class="input-group-addon" >
									Parent
								</span>
								<select class="form-control" id="option_desc" name="option_desc">
									<option value="parent">parent</option>
									<option value="#">-</option>
									<option value="m:home">Home</option>
									<option value="m:organisasi">Organisasi</option>
									<option value="m:news">News</option>
									<option value="m:events">Events</option>
									<option value="m:gallery">Gallery</option>
									<?php foreach($menu as $row):?>
									<option value="<?php echo $row->option_id?>" ><?php echo $row->option_name?></option>
									<?php endforeach;?>
								</select>
								<span class="input-group-addon" >
									<input type="radio" id="option_post" name="check" value="post" >
								</span>
								<select class="form-control option_value" name="urlMenu">
									<option value="#">-</option>
									<?php foreach($posts->result() as $row):?>
									<option value="<?php echo $row->post_id?>" ><?php echo $row->post_title?></option>
									<?php endforeach;?>
								</select>
								<span class="input-group-addon" >
									<input type="radio" id="option_url" name="check" value="url">
								</span>
								<input type="text" class="form-control option_value_l" name="option_value" placeholder="http://">
							</div>
							<p class="help-block">Pilih dari post tipe static. atau buat <a href="<?php echo site_url('iaadmin/addPost')?>">post</a> baru.</p>
							<button class="btn btn-success" type="submit"><i class="fa fa-save"></i> Update</button>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>