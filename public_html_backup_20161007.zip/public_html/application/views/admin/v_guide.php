<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title">
			<i class="fa fa-question-circle"></i> Guide
		</div>
	</div>
	<div class="panel-body">
		<?php $this->load->view('admin/_notice');?>
		<h2 class="title">POST</h2>
		<ul>
			<li>Pilih menu <span class="label label-danger">posts</span></li>
			<li>Klik tombol <span class="label label-danger">New Post</span></li>
			<li>Isi seluruh input field. untuk post type ada 2 macam, yaitu <span class="label label-danger">post</span> untuk post biasa yang akan ditampilkan dengan category dan 
			<span class="label label-danger">Static</span> yang akan digunakan untuk halaman navigasi di web (seperti visi &apm; Misi dll )
			</li>
			<li>Untuk menambah media, klik url media yang berada di table. setelah di copy klik tombol image dan paste url</li>
			<li>jika sudah selesai, klik tombol <span class="label label-danger">submit</span></li>
		</ul>
		<h2 class="title">Media</h2>
		<ul>
			<li>Pilih menu <span class="label label-danger">posts</span></li>
			<li>isi input field yang berada dibawah</li>
			<li>check untuk menampilkan media/gambar di halaman gallery</li>
			<li>klik tombol <span class="label label-danger">upload</span></li>
			<li>jika error periksa kembali rule upload</li>
		</ul>
		<h2 class="title">Event</h2>
		<ul>
			<li>Pilih menu <span class="label label-danger">events</span></li>
			<li>Klik tombol <span class="label label-danger">new event</span></li>
			<li>Isi seluruh field</li>
			<li>untuk menambah media/gambar, lakukan seperti post</li>
			<li>setelah itu pilih lokasi dengan klik klik tombol <span class="label label-danger">pick</span>. masukan alamat atau drag map, setelah selesah close 
			atau klik tombol <span class="label label-danger">pick</span>
			</li>
			<li>setelah selesai simpan dengan klik tombol <span class="label label-danger">save</span></li>
		</ul>
		<h2 class="title">User Group</h2>
		<ul>
			<li><b>root</b> dapat hak akses penuh</li>
			<li><b>Admin</b> dapat hak akses penuh</li>
			<li><b>Author</b> dapat hak akses untuk membuat/hapus/edit post dan event</li>
			<li><b>User/Subscriber</b> User yang hanya mendapatkan email tentang post dan event baru.<b>(belum aktif)</b></li>
		</ul>
		<h2 class="title">Add Menu/Submenu</h2>
		<ul>
			<li>Pilih menu <span class="label label-danger">Menu</span> untuk menambah menu, lalu scroll ke bawah</li>
			<li>Masukan input pada <span class="label label-danger">Add Menu</span> atau <span class="label label-danger">Add Submenu</span></li>
			<li>Pilih parent untuk <span class="label label-danger">Submenu</span>. <span class="label label-danger">Menu</span> yang telah diinput juga dapat menjadi parent</li>
			<li>Pilih <span class="label label-danger">post</span> untuk link menuju post, dan isi link untuk masukan secara manual (contoh google.com)</li>
			<li>klik tombol <button class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Add</button></li>
		</ul>
	</div>
</div>