<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="panel-title">
			<i class="fa fa-newspaper-o"></i> Post / Add Post
		</div>
	</div>
	<div class="panel-body">
		<form action="<?php echo site_url('iaadmin/savePost');?>" class="form-horizontal" method="POST">
			<div class="form-group">
				<label class="col-sm-2 control-label">Post Title</label>
				<div class="col-sm-6">
					<input type="text" name="postTitle" class="form-control" placeholder="title" autocomplete="off">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Post Type</label>
				<div class="col-sm-6">
					<select name="postType" class="form-control">
						<?php foreach($post_type as $key => $val):?>
						<option value="<?php echo $key?>"><?php echo $val?></option>
						<?php endforeach;?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Post Category</label>
				<div class="col-sm-6">
					<select class="form-control" name="postCategory">
						<?php foreach($category->result() as $row):?>
							<option value="<?php echo $row->category_id?>"><?php echo $row->category_name?></option>
						<?php endforeach;?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Post Content</label>
				<div class="col-sm-10">
					<p class="help-block">Use <i class="fa fa-quote-left"></i> /**more**/ <i class="fa fa-quote-right"></i> for break page.</p>
					<textarea name="postContent" id="editor" class="form-control" style="overflow-y:scroll;height:600px;" placeholder="text here..."></textarea>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label"></label>
				<div class="col-sm-10">
					<button type="submit" class="btn btn-primary"><i class="fa fa-plus-circle"></i> submit</button>
				</div>
			</div>
		</form>
		<h2 class="title">Media</h2>
		<?php $i=1;if($media->num_rows()>0):?>
			<table id="mediaTable" class="table">
				<thead>
				<tr>
					<th>#</th>
					<th>Name</th>
					<th>URL</th>
					<th>Status</th>
					<th>Action</th>
				</tr>
				</thead>
				<tbody>
				<?php foreach($media->result() as $row):?>
				<tr>
					<td><?php echo $row->media_id;?></td>
					<td><?php echo $row->media_realname;?></td>
					<td><a class="copyText" title="copy"><?php echo $row->media_url;?></a></td>
					<td><?php echo getMediaStatus($row->media_status);?></td>
					<td>
						<div class="btn-group">
							<?php if($row->media_status == 1):?>
								<a class="btn btn-sm btn-danger" href="<?php echo site_url('iaadmin/deleteMedia/'.$row->media_id)?>" title="delete"><i class="fa fa-times"></i></a>
							<?php else:?>
								<a class="btn btn-sm btn-danger" href="<?php echo site_url('iaadmin/dropMedia/'.$row->media_id)?>" title="permanent delete"><i class="fa fa-times"></i></a>
								<a class="btn btn-sm btn-success" href="<?php echo site_url('iaadmin/restoreMedia/'.$row->media_id)?>" title="active"><i class="fa fa-recycle"></i></a>
							<?php endif;?>
							<button class="btn btn-sm btn-default btn-load-image" title="view" data-toggle="modal" data-target="#myModal" data-url="<?php echo base_url($row->media_url)?>">
								<i class="fa fa-image"></i>
							</button>
						</div>
					</td>
				</tr>
				<?php endforeach;?>
				</tbody>
			</table>
			<?php else:?>
			<div class="well">No media record</div>
			<?php endif;?>
		<!-- Modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Image</h4>
			  </div>
			  <div class="modal-body">
				<div id="modal-image"></div>
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			  </div>
			</div>
		  </div>
		</div>
		<script>
			$(document).ready(function(){
				// $('#toGUI').click(function (e) {
					// var editorVal = $('#editor').val();
					// var htmlVal = $('#textHTML').val();
					// if(editorVal != htmlVal){
						// $('#editor').val(htmlVal);
					// }
				// });
				// $('#toHTML').click(function (e) {
					// var editorVal = $('#editor').val();
					// var htmlVal = $('#textHTML').val();
					// if(editorVal != htmlVal){
						// $('#textHTML').val(editorVal);
					// }
				// });
				$('#editor').wysihtml5({
					color: false,
					stylesheets: ["<?php echo base_url()?>assets/css/editor.css"],
				});
				$('#mediaTable').dataTable( {
					"order": [[3,"asc"],[ 0, "desc" ]],
					"sDom": '<"top"f>rt<"bottom"p><"clear">'
				} );
				$('.copyText').click(function(e){
					var text = '<?php echo base_url()?>'+$(this).text();
					window.prompt("Copy to clipboard: Ctrl+C, Enter", text);
				});
				$('.btn-load-image').click(function(e){
					var url = $(this).attr('data-url');
					$('#modal-image').html('<img class="img" src='+url+'>');
				});
			
			});
		</script>
	</div>
</div>