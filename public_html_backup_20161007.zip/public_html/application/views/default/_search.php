<div class="widget">
	<h2 class="title">Search</h2>
	<div class="widget-content">
		<form action="<?php echo base_url('home/search');?>" class="form" rule="form" method="POST">
			<div class="form-group">
				<div class="input-group">
					<input type="text" name="search" class="form-control" placeholder="Search">
					<span class="input-group-btn">
						<button class="btn btn-primary" type="button"><span class="fa fa-search"><span></button>
					</span>
				</div>
			</div>
		</form>
	</div>
</div>