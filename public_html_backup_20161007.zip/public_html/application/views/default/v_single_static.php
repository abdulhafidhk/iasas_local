				<div class="row">
					<div class="col-md-12">
						<div class="post-timeline">
							<div class="post">
							<?php if($post):?>
									<h2 class="title"><?php echo strtoupper($post->post_title)?></h2>
									<?php if($this->session->userdata('is_login')):?>
										<span title="Edit Post"><a href="<?php echo base_url('iaadmin/editPost/'.$post->post_id);?>"><i class="fa fa-pencil-square-o"></i> Edit</a></span>
									<?php endif;?>
									<div class="post-content">
										<?php echo removeReadmore($post->post_content);?>
									</div>
							<?php else:?>
								<div class="alert alert-danger">
									Post tidak ditemukan
								</div>
							<?php endif;?>
							</div>
						</div>
					</div>
				</div>