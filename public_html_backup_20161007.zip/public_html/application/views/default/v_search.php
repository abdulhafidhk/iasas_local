				<div class="row">
					<div class="col-md-8">
						<div class="post-timeline">
							<h2>Anda mencari: <?php echo $search?></h2>
							<h2 class="title">Posts</h2>
							<?php if($posts->num_rows() > 0):?>
								<?php foreach($posts->result() as $row):?>
									<div class="post">
										<h2 class=""><a href="<?php echo base_url('home/post/'.$row->post_id);?>"><?php echo strtoupper($row->post_title)?></a></h2>
										<div class="post-meta">
											<span><i class="fa fa-pencil"></i> <?php echo $row->user_name;?> </span>
											<span><i class="fa fa-tags"></i> <?php echo $row->category_name;?> </span>
											<span><i class="fa fa-clock-o"></i> <?php echo date('M d, Y - H:i:s',$row->post_date);?></span>
											<?php if($this->session->userdata('is_login')):?>
											<span title="Edit Post"><a href="<?php echo base_url('iaadmin/editPost/'.$row->post_id);?>"><i class="fa fa-pencil-square-o"></i> Edit</a></span>
											<?php endif;?>
										</div>
									</div>
								<?php endforeach;?>
							<?php else:?>
								<div class="alert alert-danger">
									Post tidak ditemukan
								</div>
							<?php endif;?>
							<div align="center">
								<?php echo $post_link?>
							</div>
							<h2 class="title">Events</h2>
							<?php if($events->num_rows() > 0):?>
								<?php foreach($events->result() as $row):?>
									<div class="post">
										<h2 class=""><a href="<?php echo base_url('home/event/'.$row->event_id);?>"><?php echo strtoupper($row->event_title)?></a></h2>
										<div class="post-meta">
											<span><i class="fa fa-user"></i> <?php echo $row->user_name;?> </span>
											<span><i class="fa fa-tags"></i> <?php echo $row->eg_name;?> </span>
											<span><i class="fa fa-clock-o"></i> <?php echo date('M d, Y',$row->event_date);?></span>
											<?php if($this->session->userdata('is_login')):?>
											<span title="Edit event"><a href="<?php echo base_url('iaadmin/editEvent/'.$row->event_id);?>"><i class="fa fa-pencil-square-o"></i> Edit</a></span>
											<?php endif;?>
										</div>
									</div>
								<?php endforeach;?>
							<?php else:?>
								<div class="alert alert-danger">
									Post tidak ditemukan
								</div>
							<?php endif;?>
							<div align="center">
								<?php echo $event_link?>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="sidebar-panel">
							<?php $this->load->view('default/_search');?>
							<div class="widget">
								<h2 class="title">Calendar</h2>
								<div class="widget-content">
									<div id="showdate"></div>
									<script>
										$("#showdate").datepicker();
									</script>
								</div>
							</div>
							<?php $this->load->view('default/_twitter_widget');?>
						</div>
					</div>
				</div>