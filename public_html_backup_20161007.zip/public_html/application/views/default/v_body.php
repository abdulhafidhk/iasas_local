<?php $this->load->view('default/v_header');?>
		<div id="content">
			<div class="container">
				<?php $this->load->view('default/_notice');?>
				<?php echo $content;?>
			</div>
		</div>
		<div id="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div style="">
							<h3 class="title">Social</h3>
							<ul class="list">
								<?php if($config[5]->option_value != '#'):?>
									<li><a href="<?php echo $config[5]->option_value?>" ><i class="fa fa-facebook"></i> Facebook </a></li>
								<?php endif;?>
								<?php if($config[6]->option_value != '#'):?>
									<li><a href="<?php echo $config[6]->option_value?>" ><i class="fa fa-twitter"></i> Twitter </a></li>
								<?php endif;?>
								<?php if($config[7]->option_value != '#'):?>
									<li><a href="<?php echo $config[7]->option_value?>" ><i class="fa fa-google-plus"></i> Google+ </a></li>
								<?php endif;?>
							</ul>
						</div>
					</div>
					<div class="col-md-4">
						<h3 class="title">Subscribe</h3>
						<p>
							Get our news-letter, insert your mail here
						</p>
						<form action="<?php echo base_url('home/addSubscribe');?>" class="form" rule="form" method="POST">
							<div class="form-group">
								<div class="input-group">
									<input type="email" name="uEmail" class="form-control" placeholder="your email">
									<span class="input-group-btn">
										<button class="btn btn-default" type="submit"><span class="fa fa-envelope"><span></button>
									</span>
								</div>
							</div>
						</form>
					</div>
					<div class="col-md-4">
						<h3 class="title">Address</h3>
						<p>
							<i class="fa fa-home"></i> <?php echo $config[1]->option_value?> 
						</p>
						<p>
							<i class="fa fa-phone"></i> <?php echo $config[3]->option_value?> 
							<i class="fa fa-envelope"></i>  <?php echo $config[2]->option_value?>
						</p>	
					</div>
				</div>
			</div>
			<div style="background:#232323;padding:5px;">
				<div class="container">
					<p class="" style="margin:0px;" align="right"><i class="fa fa-copyright" ></i> IATASS 2015, by <b style="color:#1490DB">ahka</b>.</p>
				</div>
			</div>
		</div>
	</div>
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-59482836-1', 'auto');
ga('send', 'pageview');
</script>
<script>
window.fbAsyncInit = function() {
FB.init({
  appId      : '1519905864965860',
  xfbml      : true,
  version    : 'v2.1'
});
};

(function(d, s, id){
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) {return;}
 js = d.createElement(s); js.id = id;
 js.src = "//connect.facebook.net/en_US/sdk.js";
 fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>
</body>
</html>