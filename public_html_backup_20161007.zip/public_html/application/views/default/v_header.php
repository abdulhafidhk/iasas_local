<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="IA TASS Telkom University">
	<link rel="icon" type="image/png" href="<?php echo base_url('assets/images/logo-80x80.png')?>" />
	<?php if(isset($fb_share)):?>
	<meta property="og:title" content="<?php echo $title?>"/>
	<meta property="og:type" content="article"/>
	<meta property="og:url" content="<?php echo current_url();?>"/>
	<meta property="og:image" content="<?php echo base_url('assets/images/logo-80x80.png')?>"/>
	<meta property="og:description" content="<?php echo character_limiter(strip_tags($fb_share),150)?>"/>
	<?php endif;?>
	<!-- CSS -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/jquery-ui.min.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/main.css">
	<!-- JavaScript -->
	<script src="<?php echo base_url()?>assets/js/jquery-1.10.2.js"></script>
	<script src="<?php echo base_url()?>assets/js/jquery-ui.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/main.js"></script>
</head>
<body>
	<div class="wrap">
		<div id="header">
			<div class="container">
				<div class="pull-left">
					<a href="<?php echo base_url()?>"><img src="<?php echo base_url()?>assets/images/logo-80x80.png"></a>
				</div>
				<div class="pull-left" style="margin-left:20px;">
					<h2><?php echo $config[0]->option_value?></h2>
				</div>
				<div class="pull-right" style="margin-top:20px;">
					<ul class="h-list">
						<?php if($this->session->userdata('is_login')):?>
						<li style="color:#232323;"><a href="<?php echo base_url('iaadmin');?>" ><i class="fa fa-gear"></i> Dashboard </a></li>
						<?php endif;?>
						<?php if($config[5]->option_value != '#'):?>
							<li><a href="<?php echo $config[5]->option_value?>" ><i class="fa fa-facebook"></i> Facebook </a></li>
						<?php endif;?>
						<?php if($config[6]->option_value != '#'):?>
							<li><a href="<?php echo $config[6]->option_value?>" ><i class="fa fa-twitter"></i> Twitter </a></li>
						<?php endif;?>
						<?php if($config[7]->option_value != '#'):?>
							<li><a href="<?php echo $config[7]->option_value?>" ><i class="fa fa-google-plus"></i> Google+ </a></li>
						<?php endif;?>
					</ul>
				</div>
			</div>
		</div>
		<div id="nav-header">
			<div class="container">
				<ul class="nav-header">
					<li><a href="<?php echo base_url()?>">Home <?php echo ($cm_home > 0)?'<i class="fa fa-angle-down"></i>':'';?></a>
						<?php if($cm_home > 0):?>
						<ul>
						<?php foreach($submenu->result() as $row):if($row->option_desc=='m:home'):?>
							<li><a href="<?php echo getMenuUrl($row);?>"><?php echo $row->option_name?></a></li>
						<?php endif;endforeach;?>
						</ul>
						<?php endif;?>
					</li>
					<li><a href="javascript:void(0)">Organisasi <i class="fa fa-angle-down"></i></a>
						<ul>
							<li><a href="<?php echo base_url('home/visi_misi');?>">Visi dan Misi</a></li>
							<li><a href="<?php echo base_url('home/program');?>">Program Kerja</a></li>
							<li><a href="<?php echo base_url('home/struktur');?>">Struktur Organisasi</a></li>
							<?php foreach($submenu->result() as $row):if($row->option_desc=='m:organisasi'):?>
								<li><a href="<?php echo getMenuUrl($row);?>"><?php echo $row->option_name?></a></li>
							<?php endif;endforeach;?>
						</ul>
					</li>
					<li><a href="<?php echo base_url('home/news')?>">News <?php echo ($cm_news > 0)?'<i class="fa fa-angle-down"></i>':'';?></a>
						<?php if($cm_news > 0):?>
						<ul>
						<?php foreach($submenu->result() as $row):if($row->option_desc=='m:news'):?>
							<li><a href="<?php echo getMenuUrl($row);?>"><?php echo $row->option_name?></a></li>
						<?php endif;endforeach;?>
						</ul>
						<?php endif;?>
					</li>
					<li><a href="<?php echo base_url('home/events')?>">Events <i class="fa fa-angle-down"></i></a>
						<ul>
							<li><a href="<?php echo base_url('home/events/1')?>">IA TASS</a></li>
							<li><a href="<?php echo base_url('home/events/2')?>">University</a></li>
							<?php foreach($submenu->result() as $row):if($row->option_desc=='m:events'):?>
								<li><a href="<?php echo getMenuUrl($row);?>"><?php echo $row->option_name?></a></li>
							<?php endif;endforeach;?>
						</ul>
					</li>
					<li><a href="<?php echo base_url('home/gallery')?>">Gallery <?php echo ($cm_gallery > 0)?'<i class="fa fa-angle-down"></i>':'';?></a>
						<?php if($cm_gallery > 0):?>
						<ul>
						<?php foreach($submenu->result() as $row):if($row->option_desc=='m:gallery'):?>
							<li><a href="<?php echo getMenuUrl($row);?>"><?php echo $row->option_name?></a></li>
						<?php endif;endforeach;?>
						</ul>
						<?php endif;?>
					</li>
					<?php foreach($menu->result() as $row):?>
					<li><a href="<?php echo getMenuUrl($row);?>"><?php echo $row->option_name?></a>
						<?php foreach($submenu->result() as $sm):if($sm->option_desc==$row->option_id):?>
							<li><a href="<?php echo getMenuUrl($sm);?>"><?php echo $sm->option_name?></a></li>
						<?php endif;endforeach;?>
					</li>
					<?php endforeach;?>
					<li><a href="<?php echo site_url('home/dataAlumni/');?>">Data Alumni</a></li>
						
					<?php if(FALSE):?>
					<li><a href="#">Newsletter</a></li>
					<?php endif;?>
				</ul>
			</div>
		</div>