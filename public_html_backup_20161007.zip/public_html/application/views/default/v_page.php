				<div class="row">
					<div class="col-md-8">
						<div class="post-timeline">
							<?php if($posts->num_rows() > 0):?>
								<?php foreach($posts->result() as $row):?>
									<div class="post">
										<h2 class="title"><a href="<?php echo base_url('home/post/'.$row->post_id);?>"><?php echo strtoupper($row->post_title)?></a></h2>
										<div class="post-meta">
											<span title="author"><i class="fa fa-pencil"></i> <?php echo $row->user_name;?> </span>
											<span title="Category"><i class="fa fa-tags"></i> <?php echo $row->category_name;?> </span>
											<span title="Post date"><i class="fa fa-clock-o"></i> <?php echo date('M d, Y - H:i',$row->post_date);?></span>
											<?php if($this->session->userdata('is_login')):?>
											<span title="Edit post"><a href="<?php echo base_url('iaadmin/editPost/'.$row->post_id);?>"><i class="fa fa-pencil-square-o"></i> Edit</a></span>
											<?php endif;?>
										</div>
										<div class="post-content">
											<?php echo readMorePost($row->post_content,base_url('home/post/'.$row->post_id));?>
										</div>
									</div>
								<?php endforeach;?>
							<?php else:?>
								<div class="alert alert-danger">
									Post tidak ditemukan
								</div>
							<?php endif;?>
							<div align="center">
								<?php echo $post_link?>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="sidebar-panel">
							<?php $this->load->view('default/_search');?>
							<div class="widget">
								<h2 class="title">Calendar</h2>
								<div class="widget-content">
									<div id="showdate"></div>
									<script>
										$("#showdate").datepicker();
									</script>
								</div>
							</div>
							<?php $this->load->view('default/_twitter_widget');?>
						</div>
					</div>
				</div>