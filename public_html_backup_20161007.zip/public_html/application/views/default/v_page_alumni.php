				<div class="row">
					<div class="col-md-12">
						<div class="post-timeline">
							<form action="<?php echo base_url('home/searchAlumni');?>" class="form" rule="form" method="GET" style="margin-top:30px;">
								<div class="form-group">
									<div class="input-group">
										<input type="text" name="q" class="form-control input-lg" placeholder="search alumni by name" value="<?php echo (isset($searchq))?$searchq:'';?>">
										<span class="input-group-btn">
											<button class="btn btn-primary btn-lg" type="button"><span class="fa fa-search"><span></button>
										</span>
									</div>
									<span id="helpBlock" class="help-block">Data alumni yang anda cari adalah dari database kami, jika data yang anda cari tidak ada mohon hubungi admin kami.</span>
								</div>
							</form>
							<?php if(isset($alumni)):?>
							<div class="post">
								<h2 class="title">DAFTAR ALUMNI</h2>
								<?php echo $page_link;?>
								<table class="table table-striped">
								<thead>
									<tr>
										<td colspan="3">Total: <?php echo $page_total;?> </td>
										<td colspan="2"><?php echo (isset($searchq))?'Search: '.$searchq:'';?></td>
										<td colspan="2"></td>
									</tr>
									<tr>
										<td>#</td>
										<td>NIM</td>
										<td>NAMA</td>
										<td>PRGORAM</td>
										<td>YUDISIUM</td>
										<td>EMAIL</td>
									</tr>
								</thead>
								<tbody style="font-family:calibri;">
									<?php foreach($alumni->result() as $row):?>
									<tr>
										<td><?php echo ++$page_offset?></td>
										<td><?php echo $row->dba_nim?></td>
										<td><?php echo $row->dba_name?></td>
										<td><?php echo $row->dba_program?></td>
										<td><?php echo $row->dba_yudisium?></td>
										<td><?php echo $row->dba_email?></td>
									</tr>
									<?php endforeach;?>
								</tbody>
								</table>
								<?php echo $page_link;?>
							</div>
							<?php endif;?>
						</div>
					</div>
				</div>