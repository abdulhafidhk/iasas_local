				<div class="row">
					<div class="col-md-8">
						<div class="post-timeline">
							<?php if($media->num_rows() > 0):?>
							<div class="row">
								<?php foreach($media->result() as $row):?>
								<div class="col-md-4">
									<div class="post" style="height:250px;">
										<div class="post-meta">
											<span><i class="fa fa-image"></i> <?php echo ($row->media_realname)?></span>
										</div>
										<a href="<?php echo base_url($row->media_url);?>" class="c-gallery"><img class="img" src="<?php echo base_url($row->media_url);?>"></a>
									</div>
								</div>
								
								<?php endforeach;?>
							</div>
							<?php else:?>
								<div class="alert alert-danger">
									Empty
								</div>
							<?php endif;?>
							<div>
								<?php echo $media_link;?>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="sidebar-panel">
							<?php $this->load->view('default/_search');?>
							<div class="widget">
								<h2 class="title">Calendar</h2>
								<div class="widget-content">
									<div id="showdate"></div>
									<script>
										$("#showdate").datepicker();
									</script>
								</div>
							</div>
							<?php $this->load->view('default/_twitter_widget');?>
						</div>
					</div>
				</div>
				<link rel="stylesheet" href="<?php echo base_url()?>assets/css/colorbox.css">
				<script src="<?php echo base_url()?>assets/js/jquery.colorbox-min.js"></script>
				<script>
					$(document).ready(function(){
						$('.c-gallery').colorbox({
						rel:'c-gallery',
						maxWidth:'100%'
						});
					});
				</script>