<div class="widget">
	<h2 class="title">Search</h2>
	<div class="widget-content">
		
	</div>
</div>