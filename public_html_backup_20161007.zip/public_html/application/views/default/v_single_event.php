				<div class="row">
					<div class="col-md-8">
						<div class="post-timeline">
							<div class="post">
							<?php if($event):?>
									<h2 class="title"><?php echo strtoupper($event->event_title)?></h2>
									<div class="post-meta">
										<span><i class="fa fa-pencil"></i> <?php echo $event->user_name;?> </span>
										<span><i class="fa fa-tags"></i> <?php echo $event->eg_name;?> </span>
										<span><i class="fa fa-clock-o"></i> <?php echo date('M d, Y',$event->event_date);?></span>
										<?php if($this->session->userdata('is_login')):?>
											<span title="Edit event"><a href="<?php echo base_url('iaadmin/editEvent/'.$event->event_id);?>"><i class="fa fa-pencil-square-o"></i> Edit</a></span>
										<?php endif;?>
									</div>
									<div class="post-content">
										<div class="" style="margin:10px;">
											<div class="fb-like" data-send="true" data-href="<?php echo current_url();?>" data-width="450" data-show-faces="true"></div>
										</div>
										<p>
											<?php echo removeReadmore($event->event_content);?>
										</p>
										<?php if(trim($event->event_location) != ""):?>
										<p>
											<h5 class="">Location: <a target="_blank" href="http://maps.google.com/?q=<?php echo $event->event_location?>"><i class="fa fa-map-marker"></i> Maps</a></h5>
											<img src="https://maps.googleapis.com/maps/api/staticmap?center=<?php echo $event->event_location?>&zoom=15&size=500x300&maptype=roadmap&markers=color:Red%7Clabel:E%7C<?php echo $event->event_location?>">
										</p>
										<?php endif;?>
									</div>
							<?php else:?>
								<div class="alert alert-danger">
									Post tidak ditemukan
								</div>
							<?php endif;?>
							<h2 class="title">Comments</h2>
							<div class="fb-comments" data-href="<?php echo current_url();?>" data-numposts="5" data-colorscheme="light"></div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="sidebar-panel">
							<?php $this->load->view('default/_search');?>
							<div class="widget">
								<h2 class="title">Calendar</h2>
								<div class="widget-content">
									<div id="showdate"></div>
									<script>
										$("#showdate").datepicker();
									</script>
								</div>
							</div>
							<?php $this->load->view('default/_twitter_widget');?>
						</div>
					</div>
				</div>