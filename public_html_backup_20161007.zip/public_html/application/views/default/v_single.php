				<div class="row">
					<div class="col-md-8">
						<div class="post-timeline">
							<div class="post">
							<?php if($post):?>
									<h2 class="title"><?php echo strtoupper($post->post_title)?></h2>
									<div class="post-meta">
										<span><i class="fa fa-pencil"></i> <?php echo $post->user_name;?> </span>
										<span><i class="fa fa-tags"></i> <?php echo $post->category_name;?> </span>
										<span><i class="fa fa-clock-o"></i> <?php echo date('M d, Y - H:i',$post->post_date);?></span>
										<?php if($this->session->userdata('is_login')):?>
											<span title="Edit post"><a href="<?php echo base_url('iaadmin/editPost/'.$post->post_id);?>"><i class="fa fa-pencil-square-o"></i> Edit</a></span>
										<?php endif;?>
									</div>
									<div class="post-content">
										<div class="" style="margin:10px;">
											<div class="fb-like" data-send="true" data-href="<?php echo current_url();?>" data-width="450" data-show-faces="true"></div>
										</div>
										<?php echo removeReadmore($post->post_content);?>
									</div>
							<?php else:?>
								<div class="alert alert-danger">
									Post tidak ditemukan
								</div>
							<?php endif;?>
							<?php if(FALSE)://if($related->num_rows()>0):?>
							<h2 class="title">Related Article</h2>
							<ul class="list">
							<?php foreach($related->result() as $row):?>
								<li><a href="<?php echo base_url('home/post/'.$row->post_id);?>"><?php echo $row->post_title?></a></li>
							<?php endforeach;?>
							</ul>
							<?php endif;?>
							<h2 class="title">Comments</h2>
							<div class="fb-comments" data-href="<?php echo current_url();?>" data-numposts="5" data-colorscheme="light"></div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="sidebar-panel">
							<?php $this->load->view('default/_search');?>
							<div class="widget">
								<h2 class="title">Calendar</h2>
								<div class="widget-content">
									<div id="showdate"></div>
									<script>
										$("#showdate").datepicker();
									</script>
								</div>
							</div>
							<?php $this->load->view('default/_twitter_widget');?>
						</div>
					</div>
				</div>