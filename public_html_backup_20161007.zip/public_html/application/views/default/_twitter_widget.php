<h2 class="title"><i class="fa fa-twitter"></i> Twitter Feed</h2>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
<a class="twitter-timeline" href="https://twitter.com/iapolitel" data-widget-id="555312361402155008">Tweet oleh @iapolitel</a>
<!-- Disable
-->