		<div class="container">
			<?php if(FALSE):?>
			<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				<!-- Wrapper for slides -->
				<div class="carousel-inner" role="listbox">
					<div class="item active">
						<div class="dummy-slide" style=""></div>
						<div class="carousel-caption">
						<h3>RED</h3>
						<p>
						Selamat Datang di Website IA TASS
							Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
							Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
						</p>
						</div>
					</div>
					<div class="item">
						<div class="dummy-slide" style=""></div>
						<div class="carousel-caption">
						<h3>GREEN</h3>
						<p>
							Selamat Datang di Official Website Ikatan Alumni Telkom Applied Science School
						</p>
						</div>
					</div>
					<div class="item">
						<div class="dummy-slide" style=""></div>
						<div class="carousel-caption">
						<h3>BLUE</h3>
						<p>
							Selamat Datang di Official Website Ikatan Alumni Telkom Applied Science School
						</p>
						</div>
					</div>
					
				</div>
				<div class="carousel-btn">
				<!-- Controls -->
				<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
				</div>
			</div>
			<?php endif;?>
			<div class="row">
				<div class="col-md-4">
					<h2 class="title">Who we are</h2>
					<p class="p">
					<?php echo $profile->option_value?>
					</p>
				</div>
				<div class="col-md-4">
					<h2 class="title"><i class="fa fa-newspaper-o"></i> Last News</h2>
					<?php if($posts->num_rows()>0):?>
						<?php foreach($posts->result() as $row):?>
						<ul class="">
							<li>
								<a class="title" href="<?php echo base_url('home/post/'.$row->post_id)?>"><?php echo $row->post_title?></a>
								<p class="p">
									<?php echo word_limiter(cleanString($row->post_content),10);?>
								</p>
								<p class="p">
									<span class="label label-danger"><i class="fa fa-user"></i> <?php echo $row->user_name?></span>
									<span class="label label-danger"><i class="fa fa-tags"></i> <?php echo $row->category_name?></span>
									<span class="label label-danger"><i class="fa fa-clock-o"></i> <?php echo date('M d, Y',$row->post_date)?></span>
								</p>
							</li>
							
						</ul>
						<?php endforeach;?>
					<?php endif;?>
					<h2 class="title"><i class="fa fa-calendar"></i> Events</h2>
					<?php if($events->num_rows()>0):?>
						<?php foreach($events->result() as $row):?>
						<ul class="">
							<li>
								<a class="title" href="<?php echo base_url('home/event/'.$row->event_id)?>"><?php echo $row->event_title?></a>
								<p class="p">
									<?php echo word_limiter(cleanString($row->event_content),10);?>
								</p>
								<p class="p">
									<span class="label label-danger"><i class="fa fa-clock-o"></i> <?php echo date('M d, Y',$row->event_date)?></span>
								</p>
							</li>
							
						</ul>
						<?php endforeach;?>
					<?php endif;?>
				</div>
				<div class="col-md-4">
					<?php $this->load->view('default/_twitter_widget');?>
				</div>
			</div>
			</div>