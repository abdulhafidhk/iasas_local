<!DOCTYPE html>
<html>
<head>
	<title>IA Politel</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/main.css">
	<!-- JavaScript -->
	<script src="<?php echo base_url();?>assets/js/jquery-1.10.2.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery-ui.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/main.js"></script>
</head>
<body style="background-image:url(<?php echo base_url()?>assets/images/noisy-texture.png)">
	<div id="login-box">
		<h2 class="title">IA TASS</h2>
		<form action="<?php echo site_url('ia_login/auth');?>" class="form" rule="form" method="POST">
			<div class="form-group">
				<label for="iusername">Username</label>
				<input type="text" class="form-control" id="iusername" name="iusername" placeholder="">
			</div>
			<div class="form-group">
				<label for="ipassword">Password</label>
				<input type="password" class="form-control" id="ipassword" name="ipassword" placeholder="">
			</div>
			<button type="submit" class="btn btn-primary"><i class="fa fa-unlock"></i> Login</button>
		</form>
		<?php $notice = $this->session->flashdata('notice');if($notice != NULL): ?>
		<div class="panel panel-warning">
			<div class="panel-heading">
				<i class="fa fa-exclamation-triangle"></i> Warning
			</div>
			<div class="panel-body">
				<?php echo $notice;?>
			</div>
		</div>
		<?php endif;?>
	</div>
</body>
</html>