<?php
class M_users extends CI_Model {
	/*----------------
	var $id = '';
	var $username = '';
	var $email = '';
	var $name = '';
	var $status = '';
	var $usergroup = '';
	var $lastlogin = '';
	------------------*/
	var $table = 'ia_users';
	
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	// data : array
	function add($data){
		$this->db->insert($this->table, $data); 
	}
	// data: array
	// where: array
	function update($data,$where){
		$this->db->where($where);
		$this->db->update($this->table, $data); 
	}
	// where: array
	function delete($where){
		$this->db->delete($this->table, $where);
	}
	// where: array
	// return: result
	function select($where=NULL){
		if(!is_null($where))$this->db->where($where);
		return $this->db->get($this->table);
	}
	// where: array
	// return: result row
	function get($where){
		$this->db->where($where);
		return $this->db->get($this->table)->row();
	}
	// username: string;
	// password: string;
	// return: result row
	function authLogin($username,$password){
		$where['user_username'] = $username;
		$where['user_password'] = md5($password);
		if($this->select($where)->num_rows > 0){
			return $this->get($where);
		}else{
			return FALSE;
		}
	}
	
}