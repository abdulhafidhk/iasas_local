<?php
class M_newsletter extends CI_Model {
	var $table = 'ia_newsletter';
	
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	// data : array
	function add($data){
		$this->db->insert($this->table, $data); 
	}
	// data: array
	// where: array
	function update($data,$where){
		$this->db->where($where);
		$this->db->update($this->table, $data); 
	}
	// where: array
	function delete($where){
		$this->db->delete($this->table, $where);
	}
	// where: array
	// return: result
	function select($where=NULL,$order='news_id ASC'){
		if(!is_null($where))$this->db->where($where);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	function selectLike($like=NULL,$order='news_id ASC'){
		if(!is_null($like))$this->db->like($like);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	// where: array
	// return: result row
	function get($where){
		$this->db->where($where);
		return $this->db->get($this->table)->row();
	}
	// limit: int
	// off: int
	// where: array
	function getPage($limit=10,$off=0,$where=NULL,$order='news_id ASC'){
		$this->db->limit($limit,$off);
		if(!is_null($where))$this->db->where($where);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	function getPageLike($limit=10,$off=0,$like=NULL,$order='news_id ASC'){
		$this->db->limit($limit,$off);
		if(!is_null($like))$this->db->like($like);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
}