<?php
class M_category extends CI_Model {
	/*----------------
	var $id = '';
	var $username = '';
	var $email = '';
	var $name = '';
	var $status = '';
	var $usergroup = '';
	var $lastlogin = '';
	------------------*/
	var $table = 'ia_category';
	
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	// data : array
	function add($data){
		$this->db->insert($this->table, $data); 
	}
	// data: array
	// where: array
	function update($data,$where){
		$this->db->where($where);
		$this->db->update($this->table, $data); 
	}
	// where: array
	function delete($where){
		$this->db->delete($this->table, $where);
	}
	// where: array
	// return: result
	function select($where=NULL){
		if(!is_null($where))$this->db->where($where);
		return $this->db->get($this->table);
	}
	// where: array
	// return: result row
	function get($where){
		return $this->db->get($this->table)->row();
	}
	// limit: int
	// off: int
	// where: array
	function getPage($limit=10,$off=0,$where=NULL){
		$this->db->limit($limit,$off);
		if(!is_null($where))$this->db->where($where);
		return $this->db->get($this->table);
	}
}