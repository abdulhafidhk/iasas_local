<?php
class M_eventgroup extends CI_Model {
	var $table = 'ia_eventgroup';
	
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	// data : array
	function add($data){
		$this->db->insert($this->table, $data); 
	}
	// data: array
	// where: array
	function update($data,$where){
		$this->db->where($where);
		$this->db->update($this->table, $data); 
	}
	// where: array
	function delete($where){
		$this->db->delete($this->table, $where);
	}
	// where: array
	// return: result
	function select($where=NULL){
		if(!is_null($where))$this->db->where($where);
		return $this->db->get($this->table);
	}
	// where: array
	// return: result row
	function get($where){
		$this->db->where($where);
		return $this->db->get($this->table)->row();
	}
	
}