<?php
class M_base extends CI_Model {
	
	
}