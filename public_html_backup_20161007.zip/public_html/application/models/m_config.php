<?php
class M_config extends CI_Model {
	// option type
	// :: val  = default
	// :: menu  
	// :: submenu
	// :: slide
	var $table = 'ia_options';
	var $webtitle = 1;
	var $address = 2;
	var $webemail = 3;
	var $phone = 4;
	var $chat = 5;
	var $facebook = 6;
	var $twitter = 7;
	var $google = 8;
	var $profile = 9;
	var $visimisi = 10;
	var $proker = 11;
	var $struktur = 12;
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	// data : array
	function add($data){
		$this->db->insert($this->table, $data); 
	}
	// data: array
	// where: array
	function update($data,$where){
		$this->db->where($where);
		$this->db->update($this->table, $data); 
	}
	// where: array
	function delete($where){
		$this->db->delete($this->table, $where);
	}
	// where: array
	// return: result
	function select($where=NULL){
		if(!is_null($where))$this->db->where($where);
		return $this->db->get($this->table);
	}
	// where: array
	// return: result row
	function get($where){
		$this->db->where($where);
		return $this->db->get($this->table)->row();
	}
	
	// val = string
	function updateWebtitle($val){
		$w['option_id'] = 1;
		$d['option_value'] = $val;
		$this->update($d,$w);
	}
	// val = string
	function updateAddress($val){
		$w['option_id'] = 2;
		$d['option_value'] = $val;
		$this->update($d,$w);
	}
	// val = string
	function updateWebmail($val){
		$w['option_id'] = 3;
		$d['option_value'] = $val;
		$this->update($d,$w);
	}
	// val = string
	function updatePhone($val){
		$w['option_id'] = 4;
		$d['option_value'] = $val;
		$this->update($d,$w);
	}
	// val = string
	function updateChat($val){
		$w['option_id'] = 5;
		$d['option_value'] = $val;
		$this->update($d,$w);
	}
	// val = string
	function updateFacebook($val){
		$w['option_id'] = 6;
		$d['option_value'] = $val;
		$this->update($d,$w);
	}
	// val = string
	function updateTwitter($val){
		$w['option_id'] = 7;
		$d['option_value'] = $val;
		$this->update($d,$w);
	}
	// val = string
	function updateGoogle($val){
		$w['option_id'] = 8;
		$d['option_value'] = $val;
		$this->update($d,$w);
	}
	// val = string
	function updateProfile($val){
		$w['option_id'] = 9;
		$d['option_value'] = $val;
		$this->update($d,$w);
	}
	// add submenu
	function addMenu($name,$value){
		$menu['option_name'] = $name;
		$menu['option_desc'] = 'parent';
		$menu['option_value'] = $value;
		$menu['option_type'] = 'menu';
		$this->add($menu);
	}
	
	function addSubMenu($name,$value,$parent){
		$menu['option_name'] = $name;
		$menu['option_desc'] = $parent;
		$menu['option_value'] = $value;
		$menu['option_type'] = 'submenu';
		$this->add($menu);
	}
	
}