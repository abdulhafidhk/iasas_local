<?php
class M_events extends CI_Model {
	var $table = 'ia_events';
	
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	// data : array
	function add($data){
		$this->db->insert($this->table, $data); 
	}
	// data: array
	// where: array
	function update($data,$where){
		$this->db->where($where);
		$this->db->update($this->table, $data); 
	}
	// where: array
	function delete($where){
		$this->db->delete($this->table, $where);
	}
	// where: array
	// return: result
	function select($where=NULL,$order='event_id DESC'){
		if(!is_null($where))$this->db->where($where);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	function selectLike($like=NULL,$order='event_id DESC'){
		if(!is_null($like))$this->db->like($like);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	function selectJoin($where=NULL,$order='event_id DESC'){
		$this->db->from($this->table);
		$this->db->join('ia_eventgroup','event_group = eg_id','left');
		$this->db->join('ia_users','event_author = user_id','left');
		if(!is_null($where))$this->db->where($where);
		$this->db->order_by($order);
		return $this->db->get();
	}
	function selectJoinLike($like=NULL,$order='event_id DESC'){
		$this->db->from($this->table);
		$this->db->join('ia_eventgroup','event_group = eg_id','left');
		$this->db->join('ia_users','event_author = user_id','left');
		if(!is_null($like))$this->db->like($like);
		$this->db->order_by($order);
		return $this->db->get();
	}
	// where: array
	// return: result row
	function get($where=NULL){
		if(!is_null($where))$this->db->where($where);
		return $this->db->get($this->table)->row();
	}
	// where: array
	// return: result row
	function getJoin($where=NULL){
		$this->db->from($this->table);
		$this->db->join('ia_eventgroup','event_group = eg_id','left');
		$this->db->join('ia_users','event_author = user_id','left');
		if(!is_null($where))$this->db->where($where);
		return $this->db->get()->row();
	}
	// limit: int
	// off: int
	// where: array
	function getPage($limit=10,$off=0,$where=NULL,$order='event_id DESC'){
		$this->db->limit($limit,$off);
		if(!is_null($where))$this->db->where($where);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	function getPageJoin($limit=10,$off=0,$where=NULL,$order='event_id DESC'){
		$this->db->from($this->table);
		$this->db->join('ia_eventgroup','event_group = eg_id','left');
		$this->db->join('ia_users','event_author = user_id','left');
		$this->db->limit($limit,$off);
		if(!is_null($where))$this->db->where($where);
		$this->db->order_by($order);
		return $this->db->get();
	}
	function getPageJoinLike($limit=10,$off=0,$like=NULL,$order='event_id DESC'){
		$this->db->from($this->table);
		$this->db->join('ia_eventgroup','event_group = eg_id','left');
		$this->db->join('ia_users','event_author = user_id','left');
		$this->db->limit($limit,$off);
		if(!is_null($like))$this->db->like($like);
		$this->db->order_by($order);
		return $this->db->get();
	}
	
}