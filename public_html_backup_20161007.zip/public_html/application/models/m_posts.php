<?php
class M_posts extends CI_Model {
	/*----------------
	var $id = '';
	var $username = '';
	var $email = '';
	var $name = '';
	var $status = '';
	var $usergroup = '';
	var $lastlogin = '';
	------------------*/
	var $table = 'ia_posts';
	
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	// data : array
	function add($data){
		$this->db->insert($this->table, $data); 
	}
	// data: array
	// where: array
	function update($data,$where){
		$this->db->where($where);
		$this->db->update($this->table, $data); 
	}
	// where: array
	function delete($where){
		$this->db->delete($this->table, $where);
	}
	// where: array
	// return: result
	function selectLike($like=NULL,$order='post_id DESC'){
		if(!is_null($like)) $this->db->like($like);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	// where: array
	// return: result
	function select($where=NULL,$order='post_id DESC'){
		if(!is_null($where)) $this->db->where($where);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	// where: array
	// return: result
	function selectJoin($where=NULL,$order='post_id DESC'){
		$this->db->from($this->table);
		$this->db->join('ia_category',' post_category_id = category_id','left');
		$this->db->join('ia_users',' post_author = user_id');
		if(!is_null($where))$this->db->where($where);
		$this->db->order_by($order);
		return $this->db->get();
	}
	// where: array
	// return: result
	function selectJoinLike($like=NULL,$order='post_id DESC'){
		$this->db->from($this->table);
		$this->db->join('ia_category',' post_category_id = category_id','left');
		$this->db->join('ia_users',' post_author = user_id');
		if(!is_null($like))$this->db->like($like);
		$this->db->order_by($order);
		return $this->db->get();
	}
	// where: array
	// return: result row
	function get($where){
		$this->db->where($where);
		return $this->db->get($this->table)->row();
	}
	// where: array
	// return: result row
	function getJoin($where){
		$this->db->from($this->table);
		$this->db->join('ia_category',' post_category_id = category_id','left');
		$this->db->join('ia_users',' post_author = user_id');
		$this->db->where($where);
		return $this->db->get()->row();
	}
	// limit: int
	// off: int
	// where: array
	function getPage($limit=10,$off=0,$where=NULL,$order='post_id DESC'){
		$this->db->limit($limit,$off);
		if(!is_null($where))$this->db->where($where);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	// limit: int
	// off: int
	// where: array
	function getPageLike($limit=10,$off=0,$like=NULL,$order='post_id DESC'){
		$this->db->limit($limit,$off);
		if(!is_null($like))$this->db->like($like);
		$this->db->order_by($order);
		return $this->db->get($this->table);
	}
	/*** JOIN ***/
	// limit: int
	// off: int
	// where: array
	function getPageJoin($limit=10,$off=0,$where=NULL,$order='post_id DESC'){
		$this->db->from($this->table);
		$this->db->join('ia_category',' post_category_id = category_id','left');
		$this->db->join('ia_users',' post_author = user_id');
		$this->db->limit($limit,$off);
		$this->db->order_by($order);
		if(!is_null($where))$this->db->where($where);
		return $this->db->get();
	}
	// limit: int
	// off: int
	// where: array
	function getPageJoinLike($limit=10,$off=0,$like=NULL,$order='post_id DESC'){
		$this->db->from($this->table);
		$this->db->join('ia_category',' post_category_id = category_id','left');
		$this->db->join('ia_users',' post_author = user_id');
		$this->db->limit($limit,$off);
		$this->db->order_by($order);
		if(!is_null($like))$this->db->like($like);
		return $this->db->get();
	}
	// category: array
	function selectByCategory($category){
		$this->db->from($this->table);
		$this->db->join('ia_category','post_category_id = category_id');
		$this->db->where_in('category_id',$category);
		return $this->db->get();
	}
	// id = int
	// function selectPostCategory($id){
		// $this->db->where('pc_post_id',$id);
		// return $this->db->get('ia_postcategory');
	// }
	/*
	OLD
	// where: array
	function getPageJoin($limit=10,$off=0,$where){
		$this->db->from($this->table);
		$this->db->join('ia_postcategory','post_id = pc_post_id');
		$this->db->join('ia_category',' category_id = pc_category_id');
		$this->db->limit($limit,$off);
		$this->db->where($where);
		return $this->db->get();
	}
	// category: array
	function selectByCategory($category){
		$this->db->from($this->table);
		$this->db->join('ia_postcategory','post_id = pc_post_id');
		$this->db->where_in('pc_category_id',$category);
		return $this->db->get();
	}
	// id = int
	function selectPostCategory($id){
		$this->db->where('pc_post_id',$id);
		return $this->db->get('ia_postcategory');
	}
	*/
}