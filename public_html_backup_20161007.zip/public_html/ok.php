<?php 
echo "EXEC OK";